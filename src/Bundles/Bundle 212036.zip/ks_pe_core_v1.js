function callBizlinks(idTransac,idProceso,subsidiary){
	var method ='callBizlinks';
	var setup =getCoreSetup(subsidiary);
	try{
	nlapiLogExecution("DEBUG", "callBizlinksControl", nlapiGetContext().getExecutionContext());
	
	nlapiLogExecution("DEBUG", "callBizlinksControl", 'Iniciando envio de factura a Bizlinks');
	var url = setup.url_dev;
	var authentication = setup.auth_dev;
	if(setup.deploy=='T'){
		url = setup.url_prod;
		authentication = setup.auth_prod;
	}
	var postdata = postData(idTransac,idProceso,subsidiary);
	nlapiLogExecution("DEBUG", method, 'url::'+url);
	nlapiLogExecution("DEBUG",method, 'authentication::'+authentication);
	nlapiLogExecution("DEBUG",method, 'subsidiary::'+subsidiary);
	var headers = {
			"Content-Type":"text/xml",
			"Authorization": authentication
	};
	
	var response = nlapiRequestURL(url, postdata, headers, 'POST');
	nlapiLogExecution("DEBUG", "callBizlinksControl", 'code::'+response.getCode());
	nlapiLogExecution("DEBUG", "callBizlinksControl", 'response::'+response.getBody());
	if(response.getCode()==200){
		processXML((response.getBody()),idTransac,idProceso);
		if(idProceso=='5'){
			nlapiSubmitField('customrecord_ks_anulacion_comprobante',idTransac,'custrecord_ks_respuesta',(response.getBody()));
		}else if(idProceso=='4'){
			var resumen = nlapiCreateRecord('customrecord_ks_pe_resumen_comprobantes');
			var fechaGeneracion = new Date();
			var month =parseInt(fechaGeneracion.getMonth())+1;
			if(parseInt(month)<10){
				month='0'+month;
			}
			var day =fechaGeneracion.getDate();
			if(parseInt(day)<10){
				day='0'+day;
			}
			resumen.setFieldValue('custrecord_ks_pe_resumen_name', 'RC-'+fechaGeneracion.getFullYear()+month+day+'-001');
			resumen.setFieldValue('custrecord_ks_pe_res_com_response', response.getBody());
//			resumen.setFieldValue('custrecord_ks_pe_res_envio', postdata);
			resumen.setFieldValue('custrecord_ks_pe_resumen_subsidiary', subsidiary);
			nlapiSubmitRecord(resumen);
			var resumenFile = nlapiCreateFile('RC-'+fechaGeneracion.getFullYear()+month+day+'-001'+'.xml', 'PLAINTEXT', postdata);
			resumenFile.setFolder(setup.carpeta);
			nlapiSubmitFile(resumenFile);
		}else{
			nlapiLogExecution("DEBUG", "callBizlinksControl", response.getBody());
		}
	}
	
	}catch(e){
		kisShowException(method, e);
	}
}
function buildSearchColumns(searchid){
	var method = 'buildSearchColumns';
	var columnsStructure = new Array();
	try{
		var filters = new Array();
		filters.push(new nlobjSearchFilter('custrecord_ks_pre_ass_busqueda', null, 'is', searchid));
		var searchresults = nlapiSearchRecord('customrecord_ks_pre_invoice_info_mapping', 'customsearch_ks_pe_invoicing_mapping', filters, null);
		if(searchresults){
			for (var i = 0; i < searchresults.length; i++) {
				var each = searchresults[i];
				var columns = each.getAllColumns();
				if(each.getValue(columns[4])!=''){
					var col_record = new nlobjSearchColumn(each.getValue(columns[4]));
					col_record.setFormula(each.getValue(columns[1]));
					columnsStructure[each.getValue(columns[2])]=col_record;
				}else{
					if(each.getValue(columns[5])!=''){
						columnsStructure[each.getValue(columns[2])]=new nlobjSearchColumn(each.getValue(columns[1]), each.getValue(columns[5]),null);
					}else{
						columnsStructure[each.getValue(columns[2])]=new nlobjSearchColumn(each.getValue(columns[1]),null);
						
					}
				}
			}
		}
	}catch(e){
		nlapiLogExecution('ERROR', method, e);
	}
	return columnsStructure;
}
function kisLog(type, method, message){
	nlapiLogExecution(type, method, message);
}
function kisShowException(method, e){
	var result = '';
	if (e instanceof nlobjError)
	{
		kisLog('ERROR', method, e.getCode() + '\n' + e.getDetails());
		result = e.getCode() + '\n' + e.getDetails();
	}    	
	else
	{
		kisLog('ERROR', method, e.toString());
		result = e.toString();
	}
	return result;
}
/**
 * Convierte deacuerdo al undiad enviada {number} fromUnit el valor enviado a el valor exprsado en la undiad requerida {number} toUnit.
 * 
 * @param {number} valor
 * @param {number} fromUnit
 * @param {toUnit} toUnit
 * 
 * @return {number} result
 */
function convertUnitTypeBasePrice(valor,unitsType,fromUnit,toUnit){
	var method = 'core.convertUnitTypeBasePrice';
	var result = 0;
	try{
		//kisLog('AUDIT',method,'fromUnit: '+fromUnit+' toUnit: '+toUnit);

		var filters = new Array();
		filters.push([['unitname','is',fromUnit],'OR',['unitname','is',toUnit]]);
		filters.push('AND');
		filters.push(['name','is',unitsType]);

		var columns = new Array();
		columns.push(new nlobjSearchColumn('name'));
		columns.push(new nlobjSearchColumn('unitname'));
		columns.push(new nlobjSearchColumn('baseunit'));
		columns.push(new nlobjSearchColumn('conversionrate'));

		var searchResults = loadMoreRecord('unitstype',null,filters,columns);
		if(searchResults){
			var filedFromUnit = new Object();
			var filedToUnit = new Object();

			for(var i=0; i<searchResults.length; i++){
				var searchResult = searchResults[i];
				var name = searchResult.getValue(columns[0]);
				var unitname = searchResult.getValue(columns[1]);
				var baseunit = searchResult.getValue(columns[2]);
				var conversionrate = searchResult.getValue(columns[3]);

				kisLog('DEBUG',method,'name:'+name+' unitname:'+unitname+' baseunit:'+baseunit+' conversionrate:'+conversionrate);
				if(unitname==fromUnit){
					filedFromUnit.name = name;
					filedFromUnit.unitname = unitname;
					filedFromUnit.baseunit = baseunit;
					filedFromUnit.conversionrate = conversionrate;
				}
				if(unitname==toUnit){
					filedToUnit.name = name;
					filedToUnit.unitname = unitname;
					filedToUnit.baseunit = baseunit;
					filedToUnit.conversionrate = conversionrate;
				}
			}

			//kisLog('DEBUG',method,'('+valor+'/'+filedFromUnit.conversionrate+')*'+filedToUnit.conversionrate);
			result = (parseFloat(valor)/parseFloat(filedFromUnit.conversionrate))*parseFloat(filedToUnit.conversionrate);

		}



	}catch(e){
		kisShowException(method, e);
	}
	return result;
}
function getUnits(){
	var method='getUnits';
	var results = new Array();
	try{
		var columns = new Array();
		columns.push(new nlobjSearchColumn('internalid'));
		columns.push(new nlobjSearchColumn('name'));
		var searchresults = nlapiSearchRecord('unitstype',null,null,columns);
		if(searchresults){
			for (var int = 0; int < searchresults.length; int++) {
				var each = searchresults[int];
				var intid = each.getValue(columns[0]);
				var name_type = each.getValue(columns[1]);
				var record = nlapiLoadRecord('unitstype',intid);
				var lines = record.getLineItemCount('uom');
				for (var j = 1; j <= lines; j++) {
					var name = record.getLineItemValue('uom', 'unitname', j);
					var exchange = record.getLineItemValue('uom', 'conversionrate', j);
					results[name]=exchange;
				}
			}
		}
	}catch(e){
		nlapiLogExecution('ERROR',method,e);
	}
	return results;
}

function getUnitsType(){
	var method='getUnits';
	var results = new Array();
	try{
		var columns = new Array();
		columns.push(new nlobjSearchColumn('internalid'));
		columns.push(new nlobjSearchColumn('name'));
      
		var searchresults = nlapiSearchRecord('unitstype',null,null,columns);
		if(searchresults){
			for (var int = 0; int < searchresults.length; int++) {
				var each = searchresults[int];
				var intid = each.getValue(columns[0]);
				var name_type = each.getValue(columns[1]);
				var record = nlapiLoadRecord('unitstype',intid);
				var lines = record.getLineItemCount('uom');
				for (var j = 1; j <= lines; j++) {
					var name = record.getLineItemValue('uom', 'unitname', j);
					var exchange = record.getLineItemValue('uom', 'conversionrate', j);
                  results[name_type +'_'+name]=exchange;
				}
			}
		}
	}catch(e){
		nlapiLogExecution('ERROR',method,e);
	}
	return results;
}
function getCoreSetup(subsidiary){
	var method='getCoreSetup';
	var setup = new Object();
	try{  
		var filters = new Array();
		if(subsidiary!=''&&subsidiary!=undefined&&subsidiary!=null){
			filters.push(new nlobjSearchFilter('custrecord_ks_pe_subsidiary_for_address', null, 'is', subsidiary));
		}else{
			filters=null;
		}
		
		var searchresults = nlapiSearchRecord(null,'customsearch_ks_pe_as_fact_elect_script',filters,null);
		if(searchresults){
			for (var i = 0; i < searchresults.length; i++) {
				var columns = searchresults[i].getAllColumns();
				setup.url_prod=searchresults[i].getValue(columns[1]);
				setup.url_dev=searchresults[i].getValue(columns[2]);
				setup.auth_prod=searchresults[i].getValue(columns[3]);
				setup.auth_dev=searchresults[i].getValue(columns[4]);
				setup.deploy=searchresults[i].getValue(columns[5]);
				setup.nit=searchresults[i].getValue(columns[6]);
				setup.name=searchresults[i].getValue(columns[7]);
				setup.subsidiary=searchresults[i].getValue(columns[8]);
				setup.ubigeo=searchresults[i].getValue(columns[9]);
				setup.bcp_pen=searchresults[i].getValue(columns[10]);
				setup.bcp_usd=searchresults[i].getValue(columns[11]);
				setup.bbva_pen=searchresults[i].getValue(columns[12]);
				setup.bbva_usd=searchresults[i].getValue(columns[13]);
				setup.bn=searchresults[i].getValue(columns[14]);
				setup.record_doc_type=searchresults[i].getValue(columns[15]);
				setup.record_field_code=searchresults[i].getValue(columns[16]);
				setup.campo_serie=searchresults[i].getValue(columns[17]);
				setup.carpeta=searchresults[i].getValue(columns[18]);
				setup.url_plantilla=searchresults[i].getValue(columns[19]);
				setup.custom_cliente=searchresults[i].getValue(columns[20]);
				setup.campo_tipo_cliente=searchresults[i].getValue(columns[21]);
				setup.counter=searchresults[i].getValue(columns[22]);
				setup.internal=searchresults[i].getValue(columns[23]);
				setup.interbank_soles=searchresults[i].getValue(columns[24]);
				setup.interbank_usd=searchresults[i].getValue(columns[25]);
				setup.email_resumen=searchresults[i].getValue(columns[26]);
				setup.consec_resumen=searchresults[i].getValue(columns[27]);
			}
		}else{
			nlapiLogExecution('ERROR',method,'No Results');
		}
	}catch(e){
		nlapiLogExecution('ERROR',method,e);
	}
	nlapiLogExecution('ERROR',method,JSON.stringify(setup));
	return setup;
}