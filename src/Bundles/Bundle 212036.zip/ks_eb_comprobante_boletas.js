function ejecutarReporteBoletas(){
	var method = 'ejecutarReporteBoletas';
	try{
		var searchresults = nlapiSearchRecord(null,'customsearch_ks_pe_as_fact_elect_script',null,null);
		if(searchresults){
			nlapiLogExecution('AUDIT', method, 'size::'+searchresults.length);
			for (var i = 0; i < searchresults.length; i++) {
				var columns = searchresults[i].getAllColumns();
				var subsidiary=searchresults[i].getValue(columns[8]);
				nlapiLogExecution('AUDIT', method, 'processing::'+subsidiary);
				callBizlinks('','4',subsidiary);
			}
		}else{
			nlapiLogExecution('ERROR',method,'No Results');
		}
		nlapiLogExecution('DEBUG',method,'init');
		
	}catch(e){
		nlapiLogExecution('ERROR',method,e);
	}	
}