/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       01 Feb 2017     William
 *
 */


/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function ks_AnulacionComprobante(type){
	var method = 'on_ks_anulaciondecomprobantes.afterSubmit';
	var recType = nlapiGetRecordType();
	var recId = nlapiGetRecordId();
	try{
		nlapiLogExecution('DEBUG',method,recType+' '+recId);
		callBizlinks(recId,'5');
	}catch(e){
		nlapiLogExecution('ERROR',method,e);
	}	
}
