/**
 * Funcion que entrega el texto XML de la estrucutura solicitada para el llamado de la funcion
 * SignOnLineCmd del servicio web de bizlinks
 * @param {String|Number} id identificador de la trasaccion
 * @param {Number}tipo indica que tipo de trasaccion se esta enviando 0 para Facturas y boletas y 1 para notas credito
 * @param {Number}ds valor para el parametro declare sunat, 1 indica que si 0 indica que no
 * @param {Number}dds valor para el parametro declare sunat direct, 1 indica que si 0 indica que no
 * @param {Number}p valor para el parametro publish, 1 indica que si 0 indica que no
 */
var setupGlobal = null;
var unidadesSunat = new Array();

function createSignOnLineCmd(id, tipo, ds, dds, p) {
    var method = 'createSignOnLineCmd';
    var xmlSignOnLineCmd;
    addUnitsSUNAT();
    var idEmisor = '';
    var tipoDocumentoAProcesar = '01';
    var tipoDocumentoEmisor = 6;
    var numeroDocumentoEmisor = '';
    var razonSocialEmisor = '';
    var tipoDocumento = "01";
    var unitsForPrinting = getUnitsType(); //getUnits();

    var hasDetraction = false;

    try {
        var filters = new Array();
        filters.push(new nlobjSearchFilter('internalid', null, 'is', id));
        var columnsMain = buildSearchColumns('customsearch_ks_invoice_info');
        //KS Invoice Infromation
        var resulteSetInvoiceInfo = nlapiSearchRecord(null, 'customsearch_ks_invoice_info', filters, columnsMain);
        nlapiLogExecution('AUDIT', method, 'resulteSetInvoiceInfo: ' + JSON.stringify(resulteSetInvoiceInfo));
        //KS Invoice Infromation Discounts
        var resulteSetInvoiceInfoDesc = nlapiSearchRecord(null, 'customsearch_ks_invoice_info_disc', filters, columnsMain);
        var columns = resulteSetInvoiceInfo[0].getAllColumns();
        var columnsHeader = resulteSetInvoiceInfo[0].getAllColumns();
        setupGlobal = getCoreSetup(resulteSetInvoiceInfo[0].getValue(columns[27]));
        nlapiLogExecution('AUDIT', method, 'tipo documento::' + resulteSetInvoiceInfo[0].getValue(columns[26]) + ' subsidiary:: ' + resulteSetInvoiceInfo[0].getValue(columns[27]));
        idEmisor = setupGlobal.nit;
        razonSocialEmisor = setupGlobal.name;
        numeroDocumentoEmisor = setupGlobal.nit;
        var serieNumero = resulteSetInvoiceInfo[0].getValue(columns[0]);
        var tipoDoc = resulteSetInvoiceInfo[0].getValue(columns[16]);
        nlapiLogExecution('AUDIT', method, 'tipo documento::' + resulteSetInvoiceInfo[0].getValue(columns[26]));
        nlapiLogExecution('AUDIT', method, 'subsidiary::' + resulteSetInvoiceInfo[0].getValue(columns[27]));
        tipoDocumentoAProcesar = resulteSetInvoiceInfo[0].getValue(columns[26]);
        tipoDocumento = resulteSetInvoiceInfo[0].getValue(columns[26]);

        xmlSignOnLineCmd = '<SignOnLineCmd declare-sunat="' + ds + '" declare-direct-sunat="' + dds + '" publish="' + p + '" output="PDF">';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<parameter value="' + idEmisor + '" name="idEmisor"/>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<parameter value="' + tipoDocumentoAProcesar + '" name="tipoDocumento"/>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<documento>';
        /**
         * INICIO: DATOS DE LA FACTURA ELECTRONICA
         */
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<serieNumero>' + resulteSetInvoiceInfo[0].getValue(columns[0]) + '</serieNumero>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<fechaEmision>' + formatingDate(resulteSetInvoiceInfo[0].getValue(columns[1])) + '</fechaEmision>';
        if (resulteSetInvoiceInfo[0].getValue(columns[23]) != '') {
            //SI EL CLIENTE REQUIERE ENVIAR FECHA DE VENCIMIENTO USAR ESTE TAG
            //xmlSignOnLineCmd = xmlSignOnLineCmd + '<fechaVencimiento>'+formatingDate(resulteSetInvoiceInfo[0].getValue(columns[23]))+'</fechaVencimiento>';
        }
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<horaEmision>00:00:00</horaEmision>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoDocumento>' + tipoDocumento + '</tipoDocumento>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoMoneda>' + formatingCurrency(resulteSetInvoiceInfo[0].getValue(columns[6])) + '</tipoMoneda>';
        /*
         * FIN: DATOS DE LA FACTURA ELECTRONICA
         * INICIO: DATOS DEL EMISOR
         */
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoDocumentoEmisor>' + tipoDocumentoEmisor + '</tipoDocumentoEmisor>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<numeroDocumentoEmisor>' + numeroDocumentoEmisor + '</numeroDocumentoEmisor>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<razonSocialEmisor>' + (razonSocialEmisor) + '</razonSocialEmisor>';
        xmlSignOnLineCmd += buildAddress(setupGlobal.subsidiary);
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoLocalAnexoEmisor>0000</codigoLocalAnexoEmisor>';
        /*
         * FIN: DATOS DEL EMISOR
         * INICIO: DATOS DEL DOCUMENTO ELECTRONICO (NOTA CREADITO O DEBITO)
         */

        var tipoNotacredito = '';
        if (tipoDocumento == '07') {
            var filters = new Array();
            filters.push(new nlobjSearchFilter('internalid', null, 'is', id));
            var columns2 = buildSearchColumns('customsearch_ks_credit_note_info');
            var resulteSetInvoiceInfo2 = nlapiSearchRecord(null, 'customsearch_ks_credit_note_info', filters, columns2);
            var serieNumeroAfectado = resulteSetInvoiceInfo2[0].getValue(columns2[0]);
            var fechaDocAfectado = resulteSetInvoiceInfo2[0].getValue(columns2[4]);
            var memo = resulteSetInvoiceInfo2[0].getValue(columns2[1]);
            var typeDoc = resulteSetInvoiceInfo2[0].getValue(columns2[2]);
            var cod = resulteSetInvoiceInfo2[0].getValue(columns2[6]);
            tipoNotacredito = cod;
            if (typeDoc == '03') {
                serieNumeroAfectado = serieNumeroAfectado.replace('F', 'B');
            }
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar100_3>9433</codigoAuxiliar100_3>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar100_3>' + (fechaDocAfectado) + '</textoAuxiliar100_3>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<serieNumeroAfectado>' + serieNumeroAfectado + '</serieNumeroAfectado>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoDocumentoReferenciaPrincipal>' + typeDoc + '</tipoDocumentoReferenciaPrincipal>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<numeroDocumentoReferenciaPrincipal>' + serieNumeroAfectado + '</numeroDocumentoReferenciaPrincipal>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoSerieNumeroAfectado>' + cod + '</codigoSerieNumeroAfectado>';
            if (tipoNotacredito == '13') {
                // xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoSerieNumeroAfectado> 13 </codigoSerieNumeroAfectado>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<motivoDocumento> AJUSTES - MONTOS Y/O FECHAS DE PAGO </motivoDocumento>';
            } else {
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<motivoDocumento>' + validateField(memo) + '</motivoDocumento>';
            }

        }
        if (tipoDocumento == '08') {
            var filters = new Array();
            filters.push(new nlobjSearchFilter('internalid', null, 'is', id));
            var columns2 = buildSearchColumns('customsearch_ks_debit_note_info');
            var resulteSetInvoiceInfo2 = nlapiSearchRecord(null, 'customsearch_ks_debit_note_info', filters, columns2);
            var serieNumeroAfectado = resulteSetInvoiceInfo2[0].getValue(columns2[0]);
            var fechaDocAfectado = resulteSetInvoiceInfo2[0].getValue(columns2[4]);
            var memo = resulteSetInvoiceInfo2[0].getValue(columns2[1]);
            var docNumeroAfectado = resulteSetInvoiceInfo2[0].getValue(columns2[0]);
            var typeDoc = resulteSetInvoiceInfo2[0].getValue(columns2[2]);
            var cod = resulteSetInvoiceInfo2[0].getValue(columns2[6]);
            if (typeDoc == '03') {
                serieNumeroAfectado = serieNumeroAfectado.replace('F', 'B');
            }

            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar100_3>9433</codigoAuxiliar100_3>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar100_3>' + (fechaDocAfectado) + '</textoAuxiliar100_3>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<serieNumeroAfectado>' + serieNumeroAfectado + '</serieNumeroAfectado>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<motivoDocumento>' + validateField(memo) + '</motivoDocumento>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoDocumentoReferenciaPrincipal>' + typeDoc + '</tipoDocumentoReferenciaPrincipal>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<numeroDocumentoReferenciaPrincipal>' + serieNumeroAfectado + '</numeroDocumentoReferenciaPrincipal>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoSerieNumeroAfectado>' + cod + '</codigoSerieNumeroAfectado>';
        }
        /*
         * FIN: DATOS DEL DOCUMENTO ELECTRONICO (NOTA CREADITO O DEBITO)
         * INICIO: DATOS DEL ADQUIRIENTE
         * Para facturas de exportacion no debe enviarse no. de documento del adquiriente
         */
        var client_type = nlapiLookupField(setupGlobal.custom_cliente, resulteSetInvoiceInfo[0].getValue(columns[2]), setupGlobal.campo_tipo_cliente);
        if (resulteSetInvoiceInfo[0].getValue(columns[29]) == 'T') {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoDocumentoAdquiriente>0</tipoDocumentoAdquiriente>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<numeroDocumentoAdquiriente>' + (resulteSetInvoiceInfo[0].getValue(columns[28])) + '</numeroDocumentoAdquiriente>';

        } else {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoDocumentoAdquiriente>' + client_type + '</tipoDocumentoAdquiriente>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<numeroDocumentoAdquiriente>' + (resulteSetInvoiceInfo[0].getValue(columns[28])) + '</numeroDocumentoAdquiriente>';
        }
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<razonSocialAdquiriente>' + (resulteSetInvoiceInfo[0].getValue(columns[4])) + '</razonSocialAdquiriente>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<correoAdquiriente>' + validateField(resulteSetInvoiceInfo[0].getValue(columns[5])) + '</correoAdquiriente>';
        /*
         * DIRECCION DEL ADQUIRIENTE
         */
        var filterscust = new Array();
        filterscust.push(new nlobjSearchFilter('internalid', null, 'is', resulteSetInvoiceInfo[0].getValue(columns[3])));
        var resulteSetCustomerAddres = nlapiSearchRecord(null, 'customsearch_ks_customer_addres', filterscust, null);
        if (resulteSetCustomerAddres) {
            var columnscus = resulteSetCustomerAddres[0].getAllColumns();
            var ubigeo = "-";
            var direccion = resulteSetCustomerAddres[0].getValue(columnscus[1]) != '' ? resulteSetCustomerAddres[0].getValue(columnscus[1]) : "-";
            var urbanizacion = resulteSetCustomerAddres[0].getValue(columnscus[2]) != '' ? resulteSetCustomerAddres[0].getValue(columnscus[2]) : "-";
            var provincia = resulteSetCustomerAddres[0].getValue(columnscus[3]) != '' ? resulteSetCustomerAddres[0].getValue(columnscus[3]) : "-";
            var departamento = resulteSetCustomerAddres[0].getValue(columnscus[4]) != '' ? resulteSetCustomerAddres[0].getValue(columnscus[4]) : "-";
            var distrito = resulteSetCustomerAddres[0].getValue(columnscus[5]) != '' ? resulteSetCustomerAddres[0].getValue(columnscus[5]) : "-";
            var pais = resulteSetCustomerAddres[0].getValue(columnscus[6]) != '' ? resulteSetCustomerAddres[0].getValue(columnscus[6]) : "-";
            if (tipoDocumento == '03') {
                //Condicion especial para las boletas
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<lugarDestino>' + direccion + '</lugarDestino>';
            } else {
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<ubigeoAdquiriente>' + ubigeo + '</ubigeoAdquiriente>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<direccionAdquiriente>' + direccion + '</direccionAdquiriente>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<urbanizacionAdquiriente>' + urbanizacion + '</urbanizacionAdquiriente>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<provinciaAdquiriente>' + provincia + '</provinciaAdquiriente>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<departamentoAdquiriente>' + departamento + '</departamentoAdquiriente>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<distritoAdquiriente>' + distrito + '</distritoAdquiriente>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<paisAdquiriente>' + pais + '</paisAdquiriente>';
                if (resulteSetInvoiceInfo[0].getValue(columns[29]) == 'T') {
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<paisPrestacionServicio>' + pais + '</paisPrestacionServicio>';
                }
            }
        }
        /*
         * FIN: DATOS DEL ADQUIRIENTE
         * INICIO: TOTALES DEL DOCUMENTO
         */

        if (resulteSetInvoiceInfo[0].getValue(columns[24]) == 'T') {
            //Gratuidades
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalValorVentaNetoOpGratuitas>' + Math.abs(resulteSetInvoiceInfo[0].getValue(columns[7])) + '</totalValorVentaNetoOpGratuitas>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoLeyenda_1>1000</codigoLeyenda_1>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoLeyenda_1>CERO Y 00/100 SOLES</textoLeyenda_1>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoLeyenda_2>1002</codigoLeyenda_2>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoLeyenda_2>TRANSFERENCIA GRATUITA DE UN BIEN Y/O SERVICIO PRESTADO GRATUITAMENTE</textoLeyenda_2>';
        } else if (resulteSetInvoiceInfo[0].getValue(columns[29]) == 'T') {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalValorVentaNetoOpExportacion>' + Math.abs(resulteSetInvoiceInfo[0].getValue(columns[7])) + '</totalValorVentaNetoOpExportacion>';


        } else {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalValorVentaNetoOpGravadas>0.00</totalValorVentaNetoOpGravadas>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalValorVentaNetoOpNoGravada>0.00</totalValorVentaNetoOpNoGravada>';
        }

        if (Number(resulteSetInvoiceInfo[0].getValue(columns[12])) != 0) {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalIgv>' + Math.abs(resulteSetInvoiceInfo[0].getValue(columns[8])).toFixed(2) + '</totalIgv>';
        } else {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalIgv>' + (Math.abs(resulteSetInvoiceInfo[0].getValue(columns[34]))).toFixed(2) + '</totalIgv>';
        }
        if (parseFloat(resulteSetInvoiceInfo[0].getValue(columns[30])) > 0) {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<montoBaseIsc>-MONTOBASEISC-</montoBaseIsc>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalIsc>' + Math.abs(resulteSetInvoiceInfo[0].getValue(columns[30])) + '</totalIsc>';
            var totalImpuestosComp = Math.abs(parseFloat(resulteSetInvoiceInfo[0].getValue(columns[30]))) + Math.abs(parseFloat(resulteSetInvoiceInfo[0].getValue(columns[8])));
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalImpuestos>' + (parseFloat(totalImpuestosComp).toFixed(2)) + '</totalImpuestos>';
        } else {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalImpuestos>' + Math.abs(resulteSetInvoiceInfo[0].getValue(columns[34])).toFixed(2) + '</totalImpuestos>';
        }

        /*
         * FIN: TOTALES DEL DOCUMENTO
         * INICIO: MONTOS DE DESCUENTO
         */
        if (tipoDocumento != '07' && tipoDocumento != '08') {
            if (resulteSetInvoiceInfoDesc != null) {
                var baseDescuento = Math.abs((resulteSetInvoiceInfoDesc[0].getValue(columns[9]))) + Math.abs(resulteSetInvoiceInfo[0].getValue(columns[10]));
                var montoDescuento = Math.abs((resulteSetInvoiceInfoDesc[0].getValue(columns[9])));
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<montoBaseDescuentoGlobal>' + parseFloat(baseDescuento).toFixed(2) + '</montoBaseDescuentoGlobal>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalDescuentos>' + parseFloat(montoDescuento).toFixed(2) + '</totalDescuentos>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<porcentajeDsctoGlobal>' + parseFloat((montoDescuento / baseDescuento) * 100).toFixed(2) + '</porcentajeDsctoGlobal>';
            }
        }

        if (tipoNotacredito == '13') {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalVenta>0.00</totalVenta>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalValorVenta>0.00</totalValorVenta>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalPrecioVenta>0.00</totalPrecioVenta>';
        } else {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalVenta>' + parseFloat(Math.abs(resulteSetInvoiceInfo[0].getValue(columns[10]))).toFixed(2) + '</totalVenta>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalValorVenta>' + parseFloat(Math.abs(resulteSetInvoiceInfo[0].getValue(columns[33]))).toFixed(2) + '</totalValorVenta>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalPrecioVenta>' + parseFloat(Math.abs(resulteSetInvoiceInfo[0].getValue(columns[10]))).toFixed(2) + '</totalPrecioVenta>';
        }
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<inHabilitado>1</inHabilitado>';

        //Detraccion
        var detraCode = resulteSetInvoiceInfo[0].getValue(columns[36]);
        var detraRate = resulteSetInvoiceInfo[0].getValue(columns[38]);
        var detraAmount = resulteSetInvoiceInfo[0].getValue(columns[37]);
        var medioPago = resulteSetInvoiceInfo[0].getValue(columns[39]);
        // nlapiLogExecution('DEBUG', 'detraCode', detraCode + ' - ' + typeof(detraCode));
        // nlapiLogExecution('DEBUG', 'detraRate', parseFloat(detraRate) + ' - ' + typeof(parseFloat(detraRate)));
        // nlapiLogExecution('DEBUG', 'detraAmount', parseFloat(detraAmount) + ' - ' + typeof(parseFloat(detraAmount)));
        if (medioPago && medioPago != '') {
            medioPago = medioPago.substring(0, 3);
        }
        // nlapiLogExecution('DEBUG', 'medioPago', medioPago + ' - ' + typeof(medioPago));
        if (detraCode && detraCode != '' && (tipoDocumento == '01' || tipoDocumento == '03' || tipoDocumento == '08')) {
            hasDetraction = true;
        }

        if (hasDetraction) {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoOperacion>1001</tipoOperacion>';
        } else {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoOperacion>' + (resulteSetInvoiceInfo[0].getValue(columns[31])) + '</tipoOperacion>';
        }
        /*
         * FIN: MONTOS DE DESCUENTO
         * INICIO: CAMPOS PERSONALIZADOS
         */
        //Orden de venta
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar100_1>9845</codigoAuxiliar100_1>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar100_1>' + resulteSetInvoiceInfo[0].getValue(columns[11]) + '</textoAuxiliar100_1>';
        //Tipo de cambio
        if (resulteSetInvoiceInfo[0].getValue(columns[18]) != '') {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar40_1>9351</codigoAuxiliar40_1>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar40_1>' + resulteSetInvoiceInfo[0].getValue(columns[18]) + '</textoAuxiliar40_1>';
        }
        //Due Date
        if (resulteSetInvoiceInfo[0].getValue(columns[23]) != '') {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar40_2>9093</codigoAuxiliar40_2>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar40_2>' + resulteSetInvoiceInfo[0].getValue(columns[23]) + '</textoAuxiliar40_2>';
        }
        //Memo
        if (resulteSetInvoiceInfo[0].getValue(columns[17]) != '') {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar100_2>9081</codigoAuxiliar100_2>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar100_2>' + resulteSetInvoiceInfo[0].getValue(columns[17]) + '</textoAuxiliar100_2>';
        }
        if (resulteSetInvoiceInfo[0].getValue(columns[15]) != '') {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoLeyenda_1>1000</codigoLeyenda_1>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoLeyenda_1>SON: ' + resulteSetInvoiceInfo[0].getValue(columns[15]) + '</textoLeyenda_1>';
        }

        // CAMPOS AGREGADOS 16/02/2021
        var tx_lookup = nlapiLookupField('transaction', id, ['custbody_pk_orden_compra', 'custbody_pk_codigo_gr']);
        var codeGr = tx_lookup.custbody_pk_codigo_gr ? tx_lookup.custbody_pk_codigo_gr : '-'

        xmlSignOnLineCmd = xmlSignOnLineCmd + '<ordenCompra>' + tx_lookup.custbody_pk_orden_compra + '</ordenCompra>'.replace(/\r\n/g, '');

        nlapiLogExecution('DEBUG', 'hasDetraction', hasDetraction);
        var tipoCambio = parseFloat(resulteSetInvoiceInfo[0].getValue(columns[18]));
        if (hasDetraction) {
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoDetraccion>' + detraCode + '</codigoDetraccion>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<numeroCtaBancoNacion>' + (setupGlobal.bn).replace('Nro. ', '').replace(/-/g, '') + '</numeroCtaBancoNacion>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<formaPago>' + medioPago + '</formaPago>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalDetraccion>' + parseFloat(detraAmount).toFixed(2) + '</totalDetraccion>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<porcentajeDetraccion>' + parseFloat(detraRate) + '</porcentajeDetraccion>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoLeyenda_4>2006</codigoLeyenda_4>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoLeyenda_4>OPERACION SUJETA AL SISTEMA DE PAGO DE OBLIGACIONES TRIBUTARIAS</textoLeyenda_4>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar100_4></codigoAuxiliar100_4>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar100_4></textoAuxiliar100_4>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar100_5>9777</codigoAuxiliar100_5>';
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar100_5>es_PE</textoAuxiliar100_5>';
        }

        xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar250_1>9840</codigoAuxiliar250_1>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar250_1>' + setupGlobal.bcp_pen + '</textoAuxiliar250_1>'.replace(/\r\n/g, '');
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar250_2>9838</codigoAuxiliar250_2>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar250_2>' + setupGlobal.bcp_usd + '</textoAuxiliar250_2>'.replace(/\r\n/g, '');
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar250_3>9877</codigoAuxiliar250_3>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar250_3>' + setupGlobal.bbva_pen + '</textoAuxiliar250_3>'.replace(/\r\n/g, '');
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar250_4>9875</codigoAuxiliar250_4>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar250_4>' + setupGlobal.bbva_usd + '</textoAuxiliar250_4>'.replace(/\r\n/g, '');
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar250_5>9889</codigoAuxiliar250_5>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar250_5>' + setupGlobal.bn + '</textoAuxiliar250_5>'.replace(/\r\n/g, '');
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar250_6>9540</codigoAuxiliar250_6>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar250_6>' + setupGlobal.interbank_soles + '</textoAuxiliar250_6>'.replace(/\r\n/g, '');
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar250_7>9541</codigoAuxiliar250_7>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar250_7>' + setupGlobal.interbank_usd + '</textoAuxiliar250_7>'.replace(/\r\n/g, '');
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar250_8>2995</codigoAuxiliar250_8>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar250_8>' + codeGr + '</textoAuxiliar250_8>'.replace(/\r\n/g, '');

        // FIN: CAMPOS AGREGADOS 16/02/2021

        //Comentario
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoAuxiliar500_1>9635</codigoAuxiliar500_1>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '<textoAuxiliar500_1>EN CASO DE MORA, ESTE DOCUMENTO GENERARÁ; LAS TASAS DE INTERESES COMPENSATORIO Y MORATORIO MAS ALTOS, DE ACUERDO AL ART. 1324 Y 1333 DEL CÓDIGO CIVIL.</textoAuxiliar500_1>';
        var columnsItem = buildSearchColumns('customsearch_ks_item_info_einvo');
        if (tipoNotacredito == '13') {
            var filters = new Array();
            filters.push(new nlobjSearchFilter('internalid', null, 'is', resulteSetInvoiceInfo[0].getValue(columns[35])));
            nlapiLogExecution('DEBUG', 'Transaction related: ', resulteSetInvoiceInfo[0].getValue(columns[35]));
        }
        nlapiLogExecution('DEBUG', 'columnsItem', JSON.stringify(columnsItem));
        var resulteSetItemInfo = nlapiSearchRecord(null, 'customsearch_ks_item_info_einvo', filters, columnsItem);

        var SumaItemGravado = 0;
        var SumaItemNoGravado = 0;
        var ItemGravado = 0;
        var ItemNoGravado = 0;
        var sumaMontoBaseIsc = 0;
        if (resulteSetItemInfo) {
            nlapiLogExecution('AUDIT', method, 'lines::' + resulteSetItemInfo.length)
            for (var i = 0; i < resulteSetItemInfo.length; i++) {
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<item>';
                /**
                 * Validaciond e item de anticipos
                 */
                if (resulteSetItemInfo[i].getValue(columnsItem[1]) != 18750) {
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<indicador>D</indicador>';
                }
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<numeroOrdenItem>' + (i + 1) + '</numeroOrdenItem>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoProducto>' + resulteSetItemInfo[i].getValue(columnsItem[0]) + '</codigoProducto>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoProductoSUNAT>' + resulteSetItemInfo[i].getValue(columnsItem[15]) + '</codigoProductoSUNAT>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<descripcion>' + (resulteSetItemInfo[i].getValue(columnsItem[1]).replace(/"/g, '').replace(/<br>/g, '').replace(/[\n\r]/g, '')).trim() + '</descripcion>';
                if (unitsForPrinting[resulteSetItemInfo[i].getText(columnsItem[11]) + '_' + resulteSetItemInfo[i].getValue(columnsItem[10])] != undefined) {
                    nlapiLogExecution('AUDIT', method, 'in::' + resulteSetItemInfo[i].getText(columnsItem[11]) + '_' + resulteSetItemInfo[i].getValue(columnsItem[10]));
                    if (resulteSetItemInfo[i].getValue(columnsItem[1]) == 18750) {
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<unidadMedida>NIU</unidadMedida>';
                    } else {
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<unidadMedida>' + unidadesSunat[resulteSetItemInfo[i].getValue(columnsItem[11]) + '_' + resulteSetItemInfo[i].getValue(columnsItem[10])] + '</unidadMedida>';

                    }
                    var quantity = Math.abs(resulteSetItemInfo[i].getValue(columnsItem[2])) / parseInt(unitsForPrinting[resulteSetItemInfo[i].getText(columnsItem[11]) + '_' + resulteSetItemInfo[i].getValue(columnsItem[10])]);
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<cantidad>' + quantity + '</cantidad>';

                    if (tipoNotacredito == '13') {
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeUnitarioSinImpuesto>0.00</importeUnitarioSinImpuesto>';
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeUnitarioConImpuesto>0.00</importeUnitarioConImpuesto>';
                    } else {
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeUnitarioSinImpuesto>' + parseFloat(Math.abs(resulteSetItemInfo[i].getValue(columnsItem[4])) / quantity).toFixed(2) + '</importeUnitarioSinImpuesto>';
                        // if (resulteSetItemInfo[i].getValue(columnsItem[12]) != '') {
                        //     xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeUnitarioConImpuesto>' + parseFloat(Math.abs(resulteSetItemInfo[i].getValue(columnsItem[4]) * 1.18) / quantity).toFixed(2) + '</importeUnitarioConImpuesto>';
                        // } else {
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeUnitarioConImpuesto>' + parseFloat(Math.abs(resulteSetItemInfo[i].getValue(columnsItem[5])) / quantity).toFixed(2) + '</importeUnitarioConImpuesto>';
                        // }
                    }

                    ItemGravado = parseFloat(Math.abs(resulteSetItemInfo[i].getValue(columnsItem[5])));
                    ItemNoGravado = parseFloat(Math.abs(resulteSetItemInfo[i].getValue(columnsItem[4])));
                    if (ItemGravado == ItemNoGravado) {
                        SumaItemNoGravado += ItemNoGravado;
                    } else {
                        SumaItemGravado += ItemNoGravado;
                    }
                } else {
                    var quantity = Math.abs(resulteSetItemInfo[i].getValue(columnsItem[2]));
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<cantidad>' + Math.abs(resulteSetItemInfo[i].getValue(columnsItem[2])) + '</cantidad>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<unidadMedida>NIU</unidadMedida>';
                    if (tipoNotacredito == '13') {
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeUnitarioSinImpuesto>0.00</importeUnitarioSinImpuesto>';
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeUnitarioConImpuesto>0.00</importeUnitarioConImpuesto>';
                    } else {
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeUnitarioSinImpuesto>' + parseFloat(Math.abs(resulteSetItemInfo[i].getValue(columnsItem[4])) / quantity).toFixed(2) + '</importeUnitarioSinImpuesto>';
                        // if (resulteSetItemInfo[i].getValue(columnsItem[12]) != '') {
                        //     xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeUnitarioConImpuesto>' + Math.abs(resulteSetItemInfo[i].getValue(columnsItem[4]) * 1.18).toFixed(2) + '</importeUnitarioConImpuesto>';
                        // } else {
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeUnitarioConImpuesto>' + parseFloat(Math.abs(resulteSetItemInfo[i].getValue(columnsItem[5])) / quantity).toFixed(2) + '</importeUnitarioConImpuesto>';
                        // }
                    }
                    ItemGravado = Math.abs(resulteSetItemInfo[i].getValue(columnsItem[5]));
                    ItemNoGravado = Math.abs(resulteSetItemInfo[i].getValue(columnsItem[4]));
                    if (ItemGravado == ItemNoGravado) {
                        SumaItemNoGravado += ItemNoGravado;
                    } else {
                        SumaItemGravado += ItemNoGravado;
                    }

                }
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoImporteUnitarioConImpuesto>01</codigoImporteUnitarioConImpuesto>';
                var montoIsc = 0;
                var montoBaseIsc = 0;
                var tasaIsc = 0;
                var montoIGV = Math.abs(resulteSetItemInfo[i].getValue(columnsItem[8]));
                if (resulteSetItemInfo[i].getValue(columnsItem[12]) != '' && parseFloat(resulteSetItemInfo[i].getValue(columnsItem[12])) > 0) {
                    montoIsc = Math.abs(parseFloat(resulteSetItemInfo[i].getValue(columnsItem[12])));
                    montoBaseIsc = parseFloat(Math.abs(resulteSetItemInfo[i].getValue(columnsItem[6])));
                    tasaIsc = (montoIsc / montoBaseIsc * 100);
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeIsc>' + montoIsc.toFixed(2) + '</importeIsc>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoSistemaImpuestoISC>' + resulteSetItemInfo[i].getValue(columnsItem[13]) + '</tipoSistemaImpuestoISC>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<montoBaseIsc>' + montoBaseIsc.toFixed(2) + '</montoBaseIsc>';
                    sumaMontoBaseIsc = sumaMontoBaseIsc + montoBaseIsc;
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<tasaIsc>' + tasaIsc.toFixed(2) + '</tasaIsc>';
                    // montoIsc=Math.abs(parseFloat(resulteSetItemInfo[i].getValue(columnsItem[12])).toFixed(2));
                }

                if (tipoNotacredito == '13') {
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeTotalImpuestos>0.00</importeTotalImpuestos>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<montoBaseIgv>0.00</montoBaseIgv>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<tasaIgv>0.00</tasaIgv>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeIgv>0.00</importeIgv>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeTotalSinImpuesto>0.00</importeTotalSinImpuesto>';
                } else {
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeTotalImpuestos>' + Math.abs(parseFloat(montoIGV)).toFixed(2) + '</importeTotalImpuestos>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<montoBaseIgv>' + parseFloat(Math.abs(resulteSetItemInfo[i].getValue(columnsItem[6])) + montoIsc).toFixed(2) + '</montoBaseIgv>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<tasaIgv>' + (parseFloat(montoIGV) > 0 ? '18.00' : '0.00') + '</tasaIgv>';
                    // xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeIgv>'+parseFloat(Math.abs(resulteSetItemInfo[i].getValue(columnsItem[8]))-montoIsc).toFixed(2)+'</importeIgv>';
                    if (montoIsc > 0) {
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeIgv>' + ((Math.abs(resulteSetItemInfo[i].getValue(columnsItem[6])) + montoIsc) * 0.18).toFixed(2) + '</importeIgv>';
                    } else {
                        xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeIgv>' + Math.abs(resulteSetItemInfo[i].getValue(columnsItem[8])).toFixed(2) + '</importeIgv>';
                    }

                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeTotalSinImpuesto>' + Math.abs(parseFloat(resulteSetItemInfo[i].getValue(columnsItem[6])).toFixed(2)) + '</importeTotalSinImpuesto>';
                }


                /*
                 * Validar impuestos y cargos
                 * xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeDescuento>'+Math.abs(resulteSetItemInfo[i].getValue(columnsItem[7]))+'</importeDescuento>';
                 * xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeCargo>0.00</importeCargo>';
                 */

                xmlSignOnLineCmd = xmlSignOnLineCmd + '<codigoRazonExoneracion>' + Math.abs(resulteSetItemInfo[i].getValue(columnsItem[14])) + '</codigoRazonExoneracion>';
                xmlSignOnLineCmd = xmlSignOnLineCmd + '</item>';
                if (resulteSetItemInfo[i].getValue(columnsItem[1]) == 18750) {
                    nlapiLogExecution('AUDIT', 'createSignOnLineCmd', 'anticipos')
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<anticipo>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<indicador>A</indicador>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<numeroDocumentoEmisor>' + numeroDocumentoEmisor + '</numeroDocumentoEmisor>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<serieNumero>' + resulteSetInvoiceInfo[0].getValue(columns[25]) + '</serieNumero>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoDocumento>01</tipoDocumento>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoDocumentoEmisor>' + tipoDocumentoEmisor + '</tipoDocumentoEmisor>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoDocumentoEmisorAnticipo>' + tipoDocumentoEmisor + '</tipoDocumentoEmisorAnticipo>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<numeroDocumentoEmisorAnticipo>' + numeroDocumentoEmisor + '</numeroDocumentoEmisorAnticipo>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<tipoDocumentoAnticipo>02</tipoDocumentoAnticipo>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<serieNumeroDocumentoAnticipo>' + resulteSetInvoiceInfo[0].getValue(columns[0]) + '</serieNumeroDocumentoAnticipo>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '<totalPrepagadoAnticipo>' + Math.abs(resulteSetItemInfo[i].getValue(columnsItem[9])) + '</totalPrepagadoAnticipo>';
                    xmlSignOnLineCmd = xmlSignOnLineCmd + '</anticipo>';
                }


            }
            if (tipoNotacredito != '13') {
                //replace afecto inafecto
                xmlSignOnLineCmd = xmlSignOnLineCmd.replace(/(<totalValorVentaNetoOpGravadas>)[^<>]*(<\/totalValorVentaNetoOpGravadas>)/, "$1" + SumaItemGravado.toFixed(2) + "$2");
                xmlSignOnLineCmd = xmlSignOnLineCmd.replace(/(<totalValorVentaNetoOpNoGravada>)[^<>]*(<\/totalValorVentaNetoOpNoGravada>)/, "$1" + SumaItemNoGravado.toFixed(2) + "$2");
                // xmlSignOnLineCmd=xmlSignOnLineCmd.replace('TotalBaseIsc',parseFloat(SumaMontoBaseIsc).toFixed(2));
                xmlSignOnLineCmd = xmlSignOnLineCmd.replace('-MONTOBASEISC-', sumaMontoBaseIsc);
            }

        } else {
            nlapiLogExecution('ERROR', method, 'error in search')
        }

        if (tipoDocumento == '01' || tipoNotacredito == '13') {
            if (tipoNotacredito == '13') {
                var filters = new Array();
                filters.push(new nlobjSearchFilter('internalid', null, 'is', resulteSetInvoiceInfo[0].getValue(columns[35])));
                var columnsMain = buildSearchColumns('customsearch_ks_invoice_info');
                //KS Invoice Infromation
                resulteSetInvoiceInfo = nlapiSearchRecord(null, 'customsearch_ks_invoice_info', filters, columnsMain);
            }
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<formaPagoNegociable>' + (parseInt(resulteSetInvoiceInfo[0].getValue(columns[32])) - 1) + '</formaPagoNegociable>';
        }

        var formaPago = (parseInt(resulteSetInvoiceInfo[0].getValue(columns[32])) - 1)

        if (formaPago == 1 && tipoDocumento != '07') {
            nlapiLogExecution('DEBUG', 'resulteSetInvoiceInfo', parseFloat(Math.abs(resulteSetInvoiceInfo[0].getValue(columns[10]))).toFixed(2));
            if (hasDetraction) {
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<montoNetoPendiente>' + parseFloat(Math.abs(resulteSetInvoiceInfo[0].getValue(columns[10]) - (parseFloat(detraAmount) / tipoCambio))).toFixed(2) + '</montoNetoPendiente>';
            } else {
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<montoNetoPendiente>' + parseFloat(Math.abs(resulteSetInvoiceInfo[0].getValue(columns[10]))).toFixed(2) + '</montoNetoPendiente>';
            }
            // var resulteSetCuotesInfo = nlapiSearchRecord(null, 'customsearch_ks_cuotes_info', filters, null);
            // if (resulteSetCuotesInfo) {
            //     for (var c = 0; c < resulteSetCuotesInfo.length; c++) {
            //         var searchresult = resulteSetCuotesInfo[c];
            //         var columns = searchresult.getAllColumns();
            // if (hasDetraction && c == 0) {
            //     xmlSignOnLineCmd = xmlSignOnLineCmd + '<montoPagoCuota' + (c + 1) + '>' + (parseFloat(parseFloat(Math.abs(resulteSetCuotesInfo[c].getValue(columns[0]))).toFixed(2)) - parseFloat(detraAmount)).toFixed(2) + '</montoPagoCuota' + (c + 1) + '>';
            // } else {
            //     xmlSignOnLineCmd = xmlSignOnLineCmd + '<montoPagoCuota' + (c + 1) + '>' + parseFloat(Math.abs(resulteSetCuotesInfo[c].getValue(columns[0]))).toFixed(2) + '</montoPagoCuota' + (c + 1) + '>';
            // }
            // xmlSignOnLineCmd = xmlSignOnLineCmd + '<fechaPagoCuota' + (c + 1) + '>' + resulteSetCuotesInfo[c].getValue(columns[1]) + '</fechaPagoCuota' + (c + 1) + '>';
            //     }
            // }
            var c = 0;
            if (hasDetraction) {
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<montoPagoCuota' + (c + 1) + '>' + (parseFloat(parseFloat(Math.abs(resulteSetInvoiceInfo[0].getValue(columns[10]))).toFixed(2)) - (parseFloat(detraAmount) / tipoCambio)).toFixed(2) + '</montoPagoCuota' + (c + 1) + '>';
            } else {
                xmlSignOnLineCmd = xmlSignOnLineCmd + '<montoPagoCuota' + (c + 1) + '>' + parseFloat(Math.abs(resulteSetInvoiceInfo[0].getValue(columns[10]))).toFixed(2) + '</montoPagoCuota' + (c + 1) + '>';
            }
            xmlSignOnLineCmd = xmlSignOnLineCmd + '<fechaPagoCuota' + (c + 1) + '>' + formatingDate(resulteSetInvoiceInfo[0].getValue(columns[23])) + '</fechaPagoCuota' + (c + 1) + '>';
        }

        // if (resulteSetItemInfoDiscount) {
        //     nlapiLogExecution('AUDIT', method, 'lines of discount::' + resulteSetItemInfoDiscount.length)
        //     for (var d = 0; d < resulteSetItemInfoDiscount.length; d++) {
        //         var searchresult = resulteSetItemInfoDiscount[d];
        //         var columns = searchresult.getAllColumns();
        //         var discotunAmount = resulteSetItemInfoDiscount[d].getValue(columns[2])
        //         taxAmount += discotunAmount
        //     }
        //     xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeOpeRetencion>' + baseAmountWtax + '</importeOpeRetencion>';
        //     xmlSignOnLineCmd = xmlSignOnLineCmd + '<porcentajeRetencion>' + parseInt((taxAmount * 100) / baseAmountWtax) / 100 + '</porcentajeRetencion>';
        //     xmlSignOnLineCmd = xmlSignOnLineCmd + '<importeRetencion>' + parseFloat(taxAmount).toFixed(2) + '</importeRetencion>';
        // }

        xmlSignOnLineCmd = xmlSignOnLineCmd + '</documento>';
        xmlSignOnLineCmd = xmlSignOnLineCmd + '</SignOnLineCmd>';
        xmlSignOnLineCmd = removeDiacritics(xmlSignOnLineCmd);
        nlapiLogExecution('DEBUG', 'createSignOnLineCmd', 'finished creating');
        var file = nlapiCreateFile('TestingXML.xml', 'PLAINTEXT', xmlSignOnLineCmd);
        file.setFolder(setupGlobal.carpeta);
        var file_id = nlapiSubmitFile(file);
        nlapiLogExecution('DEBUG', 'file_id', file_id);

        xmlSignOnLineCmd = '<![CDATA[' + xmlSignOnLineCmd + ']]>';
    } catch (e) {
        nlapiLogExecution('ERROR', 'createSignOnLineCmd', e);
    }

    return xmlSignOnLineCmd;
}

function createSummaryCmd(ds, dds, p, subsidiary) {
    var method = 'createSummaryCmd';
    var xmlSignOnLineCmd = '';
    try {
        nlapiLogExecution('AUDIT', method, 'subsidiary::' + subsidiary);
        var setup = getCoreSetup(subsidiary);
        var tipoDocumentoAProcesar = 'RC';
        var idEmisor = setup.nit;
        var tipoDocumentoEmisor = 6;
        var numeroDocumentoEmisor = setup.nit;
        var razonSocialEmisor = setup.name;
        var fechaEmision = new Date();
        xmlSignOnLineCmd += '<SignOnLineSummaryCmd declare-sunat="' + ds + '" replicate="1" output="PDF">';
        xmlSignOnLineCmd += '<parameter value="' + idEmisor + '" name="idEmisor"/>';
        xmlSignOnLineCmd += '<parameter value="' + tipoDocumentoAProcesar + '" name="tipoDocumento"/>';
        xmlSignOnLineCmd += '<parameter value="185" name="version"/>';
        xmlSignOnLineCmd += '<resumen>';
        xmlSignOnLineCmd += '<tipoDocumentoEmisor>' + tipoDocumentoEmisor + '</tipoDocumentoEmisor>';
        xmlSignOnLineCmd += '<numeroDocumentoEmisor>' + numeroDocumentoEmisor + '</numeroDocumentoEmisor>';
        var fechaGeneracion = new Date();
        var month = parseInt(fechaGeneracion.getMonth()) + 1;
        if (parseInt(month) < 10) {
            month = '0' + month;
        }
        var day = fechaGeneracion.getDate();
        if (parseInt(day) < 10) {
            day = '0' + day;
        }

        xmlSignOnLineCmd += '<resumenId>' + tipoDocumentoAProcesar + '-' + fechaGeneracion.getFullYear() + month + day + '-' + setup.consec_resumen + '</resumenId>';
        xmlSignOnLineCmd += '<fechaEmisionComprobante>daterep</fechaEmisionComprobante>';
        xmlSignOnLineCmd += '<fechaGeneracionResumen>' + fechaGeneracion.getFullYear() + '-' + month + '-' + day + '</fechaGeneracionResumen>';
        xmlSignOnLineCmd += '<razonSocialEmisor>' + razonSocialEmisor + '</razonSocialEmisor>';
        xmlSignOnLineCmd += '<correoEmisor>' + setup.email_resumen + '</correoEmisor>';
        xmlSignOnLineCmd += '<resumenTipo>' + tipoDocumentoAProcesar + '</resumenTipo>';
        var filters = new Array();
        filters.push(new nlobjSearchFilter('subsidiary', null, 'is', subsidiary))
        var searchresults = nlapiSearchRecord(null, 'customsearch_ks_resumen_comprobantes', filters, null);
        if (searchresults) {
            for (var iterator = 0; iterator < searchresults.length; iterator++) {
                var record = searchresults[iterator];
                var columns = record.getAllColumns();
                xmlSignOnLineCmd += '<SummaryItem>';
                xmlSignOnLineCmd += '<numeroFila>' + (iterator + 1) + '</numeroFila>';
                var client_type = nlapiLookupField(setup.custom_cliente, record.getValue(columns[1]), setup.campo_tipo_cliente);
                xmlSignOnLineCmd += '<tipoDocumento>' + record.getValue(columns[7]) + '</tipoDocumento>';
                xmlSignOnLineCmd += '<tipoDocumentoAdquiriente>' + client_type + '</tipoDocumentoAdquiriente>';
                xmlSignOnLineCmd += '<numeroDocumentoAdquiriente>' + record.getValue(columns[2]) + '</numeroDocumentoAdquiriente>';
                xmlSignOnLineCmd += '<tipoMoneda>' + formatingCurrency(record.getValue(columns[3])) + '</tipoMoneda>';
                xmlSignOnLineCmd += '<numeroCorrelativo>' + record.getValue(columns[0]) + '</numeroCorrelativo>';
                xmlSignOnLineCmd += '<estadoItem>1</estadoItem>'
                xmlSignOnLineCmd += '<totalValorVentaOpGravadasConIgv>' + parseFloat(record.getValue(columns[6])).toFixed(2) + '</totalValorVentaOpGravadasConIgv>';
                xmlSignOnLineCmd += '<totalIsc>0</totalIsc>';
                xmlSignOnLineCmd += '<totalIgv>' + parseFloat(record.getValue(columns[5])).toFixed(2) + '</totalIgv>';
                xmlSignOnLineCmd += '<totalVenta>' + parseFloat(record.getValue(columns[4])).toFixed(2) + '</totalVenta>';
                fechaEmision = formatingDate(record.getValue(columns[8]));
                xmlSignOnLineCmd += '</SummaryItem>';
            }
        }
        xmlSignOnLineCmd = xmlSignOnLineCmd.replace('daterep', fechaEmision);
        xmlSignOnLineCmd += '</resumen>';
        xmlSignOnLineCmd += '</SignOnLineSummaryCmd> ';
        xmlSignOnLineCmd = '<![CDATA[' + xmlSignOnLineCmd + ']]>';

    } catch (e) {
        nlapiLogExecution('ERROR', 'createSignOnLineCmd', e);
    }
    return xmlSignOnLineCmd;
}

/**
 * Funcion que entrega el texto XML de la estrucutura solicitada para el llamado de la funcion
 * SignOnLineDespatchCmd del servicio web de bizlinks
 * @param {String|Number} id identificador de la trasaccion
 * @param {Number}tipo indica que tipo de trasaccion se esta enviando 0 para itemfulfillment
 * @param {Number}ds valor para el parametro declare sunat, 1 indica que si 0 indica que no
 * @param {Number}dds valor para el parametro declare sunat direct, 1 indica que si 0 indica que no
 * @param {Number}p valor para el parametro publish, 1 indica que si 0 indica que no
 */
function createSignOnLineDespatchCmd(id, tipo, ds, dds, p) {
    /*var xmlSignOnLineDespatchCmd;
     var idEmisor = 20167884491;
     var tipoDocumentoAProcesar = '09';
     var tipoDocumentoEmisor = 6;
     var numeroDocumentoEmisor = "20167884491";
     var razonSocialEmisor = "PROSAC SA";
     var tipoDocumento = "01";
     try {
         var filters = new Array();
         filters.push(new nlobjSearchFilter('internalid', null, 'is', id));
         var resulteSetInvoiceInfo = nlapiSearchRecord(null, 'customsearch_ks_itemfulfillment_info', filters, null);
         var columns = resulteSetInvoiceInfo[0].getAllColumns();
         xmlSignOnLineDespatchCmd = '<SignOnLineDespatchCmd declare-sunat="'+ds+'" declare-direct-sunat="'+dds+'" publish="'+p+'" output="PDF">';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<parameter value="'+idEmisor+'" name="idEmisor"/>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<parameter value="'+tipoDocumentoAProcesar+'" name="tipoDocumento"/>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<documento>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<serieNumeroGuia>'+resulteSetInvoiceInfo[0].getValue(columns[0])+'</serieNumeroGuia>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<fechaEmisionGuia>'+formatingDate(resulteSetInvoiceInfo[0].getValue(columns[1]))+'</fechaEmisionGuia>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<tipoDocumentoGuia>09</tipoDocumentoGuia>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<correoEmisor>-</correoEmisor>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<correoAdquiriente>'+validateField(resulteSetInvoiceInfo[0].getValue(columns[2]))+'</correoAdquiriente>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<numeroDocumentoRemitente>20167884491</numeroDocumentoRemitente>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<tipoDocumentoRemitente>6</tipoDocumentoRemitente>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<razonSocialRemitente>PROSAC SA</razonSocialRemitente>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<numeroDocumentoDestinatario>'+getIDCliente(resulteSetInvoiceInfo[0].getValue(columns[3]))+'</numeroDocumentoDestinatario>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<tipoDocumentoDestinatario>'+(resulteSetInvoiceInfo[0].getValue(columns[4]))+'</tipoDocumentoDestinatario>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<razonSocialDestinatario>'+(resulteSetInvoiceInfo[0].getValue(columns[5]))+'</razonSocialDestinatario>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<motivoTraslado>'+(resulteSetInvoiceInfo[0].getValue(columns[6]))+'</motivoTraslado>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<descripcionMotivoTraslado>'+(resulteSetInvoiceInfo[0].getValue(columns[7]))+'</descripcionMotivoTraslado>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<pesoBrutoTotalBienes>25.000</pesoBrutoTotalBienes>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<unidadMedidaPesoBruto>KG</unidadMedidaPesoBruto>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<modalidadTraslado>02</modalidadTraslado>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<numeroPlacaVehiculo>PLAVEH00</numeroPlacaVehiculo>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<numeroRucTransportista>88855522211</numeroRucTransportista>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<tipoDocumentoTransportista>6</tipoDocumentoTransportista>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<razonSocialTransportista>RAZONSOCIALTRANSPORTIST</razonSocialTransportista>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<numeroDocumentoConductor>11155599</numeroDocumentoConductor>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<tipoDocumentoConductor>1</tipoDocumentoConductor>';
         var resulteSetItemInfo = nlapiSearchRecord(null, 'customsearch_ks_itemfulfillment_inf_2', filters, null);
         if(resulteSetItemInfo){
             for (var i = 0; i < resulteSetItemInfo.length; i++) {
                 var columns = resulteSetItemInfo[i].getAllColumns();
                 xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<GuiaItem>';
                 xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<numeroOrdenItem>'+(i+1)+'</numeroOrdenItem>';
                 xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<cantidad>'+resulteSetItemInfo[i].getValue(columns[0])+'</cantidad>';
                 xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<unidadMedida>NIU</unidadMedida>';
                 xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<descripcion>'+resulteSetItemInfo[i].getValue(columns[1])+'</descripcion>';
                 xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '<codigo>'+resulteSetItemInfo[i].getValue(columns[2])+'</codigo>';
                 xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '</GuiaItem>';
             }
         }
 
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '</documento>';
         xmlSignOnLineDespatchCmd = xmlSignOnLineDespatchCmd + '</SignOnLineDespatchCmd>';
 
         xmlSignOnLineDespatchCmd = '<![CDATA['+xmlSignOnLineDespatchCmd+']]>';
     } catch (e) {
         nlapiLogExecution('ERROR', 'createSignOnLineCmd', e);
     }
     return xmlSignOnLineDespatchCmd;*/
}

/**
 * Funcion que procesa el XML de respuesta del servicio de Bizlinks
 * @param {String} strXML String de respuesta del servicio
 * @param {String|Number}idTransaccion id interno de la trasaccion sobre la cual se realiza la solicitud
 * @param {String|Number}operacion indica la operacion con la cual se generÃ¯Â¿Â½ el XML de la peticion
 */
function processXML(strXML, idTransaccion, operacion) {
    var method = 'processXML';
    try {
        nlapiLogExecution('AUDIT', method, 'XML:' + strXML);
        var returntag1 = parseInt(strXML.indexOf('<return>')) + 8;
        var returntag2 = parseInt(strXML.indexOf('</return>'));

        strXML = strXML.substring(returntag1, returntag2);

        strXML = strXML.replace(/<!\[CDATA\[/g, '');
        strXML = strXML.replace(/&lt;!\[CDATA\[/g, '');
        strXML = strXML.replace(/]]>/g, '');
        strXML = strXML.replace(/]]&gt;/g, '');
        strXML = strXML.replace(/&gt;/g, '>');
        strXML = strXML.replace(/&lt;/g, '<');
        var xmldata = nlapiStringToXML(strXML);
        nlapiLogExecution('AUDIT', method, 'After XML:' + xmldata);
        var strStatus = nlapiSelectValue(xmldata, '/ebizResponse/genericInvokeResponse/commonResponse/descriptionStatus');
        var dataStatus = nlapiSelectValue(xmldata, '/ebizResponse/genericInvokeResponse/xmlResult/document/status');
        var strFileURL = '';
        var dataDesc = nlapiSelectValue(xmldata, '/ebizResponse/genericInvokeResponse/xmlResult/document/messages/descriptionDetail');
        var hashcode = '';
        nlapiLogExecution('AUDIT', 'processXML:check', strStatus + '-' + dataDesc + '-' + dataStatus);
        if (dataStatus != 'ERROR') {
            strFileURL = nlapiSelectValue(xmldata, '/ebizResponse/genericInvokeResponse/xmlResult/document/pdfFileUrl');
            nlapiLogExecution("DEBUG", "processMXLmessageControl", 'status::' + strFileURL);
            var strxmlFileSignUrl = nlapiSelectValue(xmldata, '/ebizResponse/genericInvokeResponse/xmlResult/document/xmlFileSignUrl');
            var strxmlFileSunatUrl = nlapiSelectValue(xmldata, '/ebizResponse/genericInvokeResponse/xmlResult/document/xmlFileSunatUrl');
            hashcode = nlapiSelectValue(xmldata, '/ebizResponse/genericInvokeResponse/xmlResult/document/hashCode');

            if (nlapiGetContext().getExecutionContext() != "scheduled") {
                console.log(strxmlFileSunatUrl);
            } else {
                nlapiLogExecution("DEBUG", "processMXLmessageControl", strxmlFileSunatUrl);
            }
        }
        if (operacion != '5' && operacion != '4') {
            var transaccion = null;
            if (operacion == 1) {
                transaccion = nlapiLoadRecord('invoice', idTransaccion);
            }
            if (operacion == 2) {
                transaccion = nlapiLoadRecord('itemfulfillment', idTransaccion);
            }
            if (operacion == 3) {
                transaccion = nlapiLoadRecord('creditmemo', idTransaccion);
            }
            nlapiLogExecution("DEBUG", "processMXLmessageControl>>URL", strFileURL);
            transaccion.setFieldValue('custbody_ks_detalle_facturacionelec', dataDesc);
            transaccion.setFieldValue('custbody_ks_estado_creacion_fe', strStatus);
            transaccion.setFieldValue('custbody_ks_link_comprobante', strFileURL);
            transaccion.setFieldValue('custbody_ks_reportadoelectronicamen', 'T')
            nlapiSubmitRecord(transaccion, false, true);
        }
        if (strStatus == 'SUCCESFULL') {

            nlapiLogExecution("DEBUG", "processMXLmessageSuccess", 'context::' + strFileURL);

        } else {

            nlapiLogExecution("DEBUG", "processMXLmessageError", 'Se ha presentado un error el proceso de creacion de la factura electronica');
        }

    } catch (e) {
        nlapiLogExecution("ERROR", "processMXLmessageError_", e);
    }
}

/**
 * Funcion que crea el XML enviado en el postdata de la peticion al servicio de Bizlinks
 * @param {String|Number}internalIdTransac Id interno de la transaccion de la cual se va crear el XML
 * @param {Number}operacion numero que indica que XML se debe crear
 * @returns {String} XML generado
 */
function postData(internalIdTransac, operacion, subsidiary) {
    var method = 'postData';
    nlapiLogExecution('DEBUG', method, 'operacion::' + operacion);
    nlapiLogExecution('DEBUG', method, 'subsidiary::' + subsidiary);
    //	var postData = nlapiLoadFile(31453).getValue();
    var setup = getCoreSetup();
    var postData = nlapiRequestURL(setup.url_plantilla).getBody();
    nlapiLogExecution('DEBUG', 'CDATAInfo Post Data Before', postData);
    if (operacion == 1) {
        var SignOnLineCmd = createSignOnLineCmd(internalIdTransac, 0, 1, 1, 1);
        //		var SignOnLineCmd = createSignOnLineCmd(internalIdTransac, 0, 0,0,1);
        nlapiLogExecution('DEBUG', 'CDATAInfo', SignOnLineCmd);
        postData = postData.replace('CDATAInfo', SignOnLineCmd);
    }
    if (operacion == 2) {
        var SignOnLineDespatchCmd = createSignOnLineDespatchCmd(internalIdTransac, 0, 1, 1, 1);
        nlapiLogExecution('DEBUG', 'CDATAInfo', SignOnLineDespatchCmd);
        postData = postData.replace('CDATAInfo', SignOnLineDespatchCmd);
    }
    if (operacion == 3) {
        var SignOnLineCmd = createSignOnLineCmd(internalIdTransac, 1, 1, 1, 1);
        nlapiLogExecution('DEBUG', 'CDATAInfo', SignOnLineCmd);
        postData = postData.replace('CDATAInfo', SignOnLineCmd);
    }
    if (operacion == 4) {
        var SignOnLineCmd = createSummaryCmd(1, 1, 1, subsidiary);
        nlapiLogExecution('DEBUG', 'CDATAInfo', SignOnLineCmd);
        postData = postData.replace('CDATAInfo', SignOnLineCmd);
    }
    if (operacion == 5) {
        var SignOnLineCmd = voidCmd(internalIdTransac)
        nlapiLogExecution('DEBUG', 'CDATAInfo', SignOnLineCmd);
        postData = postData.replace('CDATAInfo', SignOnLineCmd);
    }
    if (operacion == 6) {
        var SignOnLineCmd = voidCmd(internalIdTransac)
        nlapiLogExecution('DEBUG', 'CDATAInfo', SignOnLineCmd);
        postData = postData.replace('CDATAInfo', SignOnLineCmd);
    }
    nlapiLogExecution('DEBUG', 'CDATAInfo Post Data', postData);
    return postData;
}

function zeroFillerRight(value, size, character) {
    if (value.length < size) {
        var dif_size = size - value.length;
        for (var int = 0; int < dif_size; int++) {
            value = character + value;
        }

    } else {
        value = value.substring(0, size);
    }
    return value;
}
/**
 * Anulacion de comprobantes
 */
function voidCmd(idejecucion) {

    try {

        var newRecord = nlapiLoadRecord('customrecord_ks_anulacion_comprobante', idejecucion);
        var serie = newRecord.getFieldValue('custrecord_ks_pe_anul_serie');
        var correlativoinicio = newRecord.getFieldValue('custrecord_ks_anul_correl_inicial');
        var correlativofin = newRecord.getFieldValue('custrecord_ks_anul_correl_final');
        var tipodoc = newRecord.getFieldValue('custrecord_ks_anul_tipo_doc');
        var motivo = newRecord.getFieldValue('custrecord_ks_pe_motivo_anula');
        var sub_anulacion = newRecord.getFieldValue('custrecord_ks_pe_anul_subsidiaria');
        var setup = getCoreSetup(sub_anulacion);
        var method = 'voidCmd';
        var xmlAnulacion = '';
        var numeroDocumentoEmisor = setup.nit;
        var razonSocialEmisor = setup.name;
        var counter = zeroFillerRight(setup.counter, 3, '0');
        var tipoDocumentoAProcesar = 'RA';
        var docType = nlapiLookupField(setup.record_doc_type, tipodoc, setup.record_field_code);
        var nsDocType = 'invoice';
        var dateNS = null;
        nlapiLogExecution('ERROR', 'xmlAnulacion', serie + '-' + correlativoinicio);
        nlapiLogExecution('ERROR', 'xmlAnulacion', setup.campo_serie);
        nlapiLogExecution('ERROR', 'xmlAnulacion', docType);
        var filters = new Array();
        filters.push(new nlobjSearchFilter(setup.campo_serie, null, 'contains', serie + '-' + correlativoinicio));
        filters.push(new nlobjSearchFilter('subsidiary', null, 'is', sub_anulacion));
        var columns = new Array();
        columns.push(new nlobjSearchColumn('trandate'));
        var searchresults = nlapiSearchRecord(nsDocType, 'customsearch_ks_documentos_reportados', filters, columns);
        if (searchresults) {
            for (var int = 0; int < searchresults.length; int++) {
                dateNS = searchresults[int].getValue(columns[0]);
            }
        }
        nlapiLogExecution('ERROR', 'xmlAnulacion', docType + ' ' + serie + ' ' + correlativoinicio + ' ' + correlativofin);
        xmlAnulacion += '<SignOnLineSummaryCmd declare-sunat="1"	declare-direct-sunat="1" publish="1" output="PDF">';
        xmlAnulacion += '<parameter value="' + numeroDocumentoEmisor + '" name="idEmisor"/>';
        xmlAnulacion += '<parameter value="' + tipoDocumentoAProcesar + '" name="tipoDocumento"/>';
        xmlAnulacion += '<documento>';
        var fechaGeneracion = new Date();
        var month = parseInt(fechaGeneracion.getMonth()) + 1;
        if (parseInt(month) < 10) {
            month = '0' + month;
        }
        var day = fechaGeneracion.getDate();
        if (parseInt(day) < 10) {
            day = '0' + day;
        }
        xmlAnulacion += '<numeroDocumentoEmisor>' + numeroDocumentoEmisor + '</numeroDocumentoEmisor>';
        xmlAnulacion += '<version>1.0</version>';
        xmlAnulacion += '<versionUBL>2.0</versionUBL>';
        xmlAnulacion += '<tipoDocumentoEmisor>6</tipoDocumentoEmisor>';
        xmlAnulacion += '<resumenId>' + tipoDocumentoAProcesar + '-' + fechaGeneracion.getFullYear() + month + day + '-' + counter + '</resumenId>';
        xmlAnulacion += '<fechaEmisionComprobante>' + formatingDate(dateNS) + '</fechaEmisionComprobante>';
        xmlAnulacion += '<fechaGeneracionResumen>' + fechaGeneracion.getFullYear() + '-' + month + '-' + day + '</fechaGeneracionResumen>';
        xmlAnulacion += '<razonSocialEmisor>' + razonSocialEmisor + '</razonSocialEmisor>';
        xmlAnulacion += '<correoEmisor>-</correoEmisor>';
        xmlAnulacion += '<resumenTipo>RA</resumenTipo>';
        xmlAnulacion += '<ResumenItem>';
        xmlAnulacion += '<numeroFila>1</numeroFila>';
        xmlAnulacion += '<tipoDocumento>' + docType + '</tipoDocumento>';
        xmlAnulacion += '<serieDocumentoBaja>' + serie + '</serieDocumentoBaja>';
        xmlAnulacion += '<numeroDocumentoBaja>' + correlativoinicio + '</numeroDocumentoBaja>';
        xmlAnulacion += '<motivoBaja>' + motivo + '</motivoBaja>';
        xmlAnulacion += '</ResumenItem>';
        xmlAnulacion += '</documento>';
        xmlAnulacion += '</SignOnLineSummaryCmd> ';
        xmlAnulacion = '<![CDATA[' + xmlAnulacion + ']]>';
        nlapiLogExecution('ERROR', 'xmlAnulacion', xmlAnulacion);
        nlapiSubmitField('customrecord_ks_pe_as_efact_', setup.internal, 'custrecord_ks_pe_as_anulacion', parseInt(counter) + 1)
    } catch (e) {
        nlapiLogExecution('ERROR', 'xmlAnulacion', e);
    }
    return xmlAnulacion;
}
/**
 * Funcion para validar los campos vacios
 * @param {String}value valor que desea validar
 * @returns {String} Entrega el campo validado, en caso de que sea vacio la respuesta es un guion
 */
function validateField(str) {

    var defaultDiacriticsRemovalMap = [
        { 'base': 'A', 'letters': /[\u0041\u24B6\uFF21\u00C0\u00C1\u00C2\u1EA6\u1EA4\u1EAA\u1EA8\u00C3\u0100\u0102\u1EB0\u1EAE\u1EB4\u1EB2\u0226\u01E0\u00C4\u01DE\u1EA2\u00C5\u01FA\u01CD\u0200\u0202\u1EA0\u1EAC\u1EB6\u1E00\u0104\u023A\u2C6F]/g },
        { 'base': 'AA', 'letters': /[\uA732]/g },
        { 'base': 'AE', 'letters': /[\u00C6\u01FC\u01E2]/g },
        { 'base': 'AO', 'letters': /[\uA734]/g },
        { 'base': 'AU', 'letters': /[\uA736]/g },
        { 'base': 'AV', 'letters': /[\uA738\uA73A]/g },
        { 'base': 'AY', 'letters': /[\uA73C]/g },
        { 'base': 'B', 'letters': /[\u0042\u24B7\uFF22\u1E02\u1E04\u1E06\u0243\u0182\u0181]/g },
        { 'base': 'C', 'letters': /[\u0043\u24B8\uFF23\u0106\u0108\u010A\u010C\u00C7\u1E08\u0187\u023B\uA73E]/g },
        { 'base': 'D', 'letters': /[\u0044\u24B9\uFF24\u1E0A\u010E\u1E0C\u1E10\u1E12\u1E0E\u0110\u018B\u018A\u0189\uA779]/g },
        { 'base': 'DZ', 'letters': /[\u01F1\u01C4]/g },
        { 'base': 'Dz', 'letters': /[\u01F2\u01C5]/g },
        { 'base': 'E', 'letters': /[\u0045\u24BA\uFF25\u00C8\u00C9\u00CA\u1EC0\u1EBE\u1EC4\u1EC2\u1EBC\u0112\u1E14\u1E16\u0114\u0116\u00CB\u1EBA\u011A\u0204\u0206\u1EB8\u1EC6\u0228\u1E1C\u0118\u1E18\u1E1A\u0190\u018E]/g },
        { 'base': 'F', 'letters': /[\u0046\u24BB\uFF26\u1E1E\u0191\uA77B]/g },
        { 'base': 'G', 'letters': /[\u0047\u24BC\uFF27\u01F4\u011C\u1E20\u011E\u0120\u01E6\u0122\u01E4\u0193\uA7A0\uA77D\uA77E]/g },
        { 'base': 'H', 'letters': /[\u0048\u24BD\uFF28\u0124\u1E22\u1E26\u021E\u1E24\u1E28\u1E2A\u0126\u2C67\u2C75\uA78D]/g },
        { 'base': 'I', 'letters': /[\u0049\u24BE\uFF29\u00CC\u00CD\u00CE\u0128\u012A\u012C\u0130\u00CF\u1E2E\u1EC8\u01CF\u0208\u020A\u1ECA\u012E\u1E2C\u0197]/g },
        { 'base': 'J', 'letters': /[\u004A\u24BF\uFF2A\u0134\u0248]/g },
        { 'base': 'K', 'letters': /[\u004B\u24C0\uFF2B\u1E30\u01E8\u1E32\u0136\u1E34\u0198\u2C69\uA740\uA742\uA744\uA7A2]/g },
        { 'base': 'L', 'letters': /[\u004C\u24C1\uFF2C\u013F\u0139\u013D\u1E36\u1E38\u013B\u1E3C\u1E3A\u0141\u023D\u2C62\u2C60\uA748\uA746\uA780]/g },
        { 'base': 'LJ', 'letters': /[\u01C7]/g },
        { 'base': 'Lj', 'letters': /[\u01C8]/g },
        { 'base': 'M', 'letters': /[\u004D\u24C2\uFF2D\u1E3E\u1E40\u1E42\u2C6E\u019C]/g },
        { 'base': 'N', 'letters': /[\u004E\u24C3\uFF2E\u01F8\u0143\u00D1\u1E44\u0147\u1E46\u0145\u1E4A\u1E48\u0220\u019D\uA790\uA7A4]/g },
        { 'base': 'NJ', 'letters': /[\u01CA]/g },
        { 'base': 'Nj', 'letters': /[\u01CB]/g },
        { 'base': 'O', 'letters': /[\u004F\u24C4\uFF2F\u00D2\u00D3\u00D4\u1ED2\u1ED0\u1ED6\u1ED4\u00D5\u1E4C\u022C\u1E4E\u014C\u1E50\u1E52\u014E\u022E\u0230\u00D6\u022A\u1ECE\u0150\u01D1\u020C\u020E\u01A0\u1EDC\u1EDA\u1EE0\u1EDE\u1EE2\u1ECC\u1ED8\u01EA\u01EC\u00D8\u01FE\u0186\u019F\uA74A\uA74C]/g },
        { 'base': 'OI', 'letters': /[\u01A2]/g },
        { 'base': 'OO', 'letters': /[\uA74E]/g },
        { 'base': 'OU', 'letters': /[\u0222]/g },
        { 'base': 'P', 'letters': /[\u0050\u24C5\uFF30\u1E54\u1E56\u01A4\u2C63\uA750\uA752\uA754]/g },
        { 'base': 'Q', 'letters': /[\u0051\u24C6\uFF31\uA756\uA758\u024A]/g },
        { 'base': 'R', 'letters': /[\u0052\u24C7\uFF32\u0154\u1E58\u0158\u0210\u0212\u1E5A\u1E5C\u0156\u1E5E\u024C\u2C64\uA75A\uA7A6\uA782]/g },
        { 'base': 'S', 'letters': /[\u0053\u24C8\uFF33\u1E9E\u015A\u1E64\u015C\u1E60\u0160\u1E66\u1E62\u1E68\u0218\u015E\u2C7E\uA7A8\uA784]/g },
        { 'base': 'T', 'letters': /[\u0054\u24C9\uFF34\u1E6A\u0164\u1E6C\u021A\u0162\u1E70\u1E6E\u0166\u01AC\u01AE\u023E\uA786]/g },
        { 'base': 'TZ', 'letters': /[\uA728]/g },
        { 'base': 'U', 'letters': /[\u0055\u24CA\uFF35\u00D9\u00DA\u00DB\u0168\u1E78\u016A\u1E7A\u016C\u00DC\u01DB\u01D7\u01D5\u01D9\u1EE6\u016E\u0170\u01D3\u0214\u0216\u01AF\u1EEA\u1EE8\u1EEE\u1EEC\u1EF0\u1EE4\u1E72\u0172\u1E76\u1E74\u0244]/g },
        { 'base': 'V', 'letters': /[\u0056\u24CB\uFF36\u1E7C\u1E7E\u01B2\uA75E\u0245]/g },
        { 'base': 'VY', 'letters': /[\uA760]/g },
        { 'base': 'W', 'letters': /[\u0057\u24CC\uFF37\u1E80\u1E82\u0174\u1E86\u1E84\u1E88\u2C72]/g },
        { 'base': 'X', 'letters': /[\u0058\u24CD\uFF38\u1E8A\u1E8C]/g },
        { 'base': 'Y', 'letters': /[\u0059\u24CE\uFF39\u1EF2\u00DD\u0176\u1EF8\u0232\u1E8E\u0178\u1EF6\u1EF4\u01B3\u024E\u1EFE]/g },
        { 'base': 'Z', 'letters': /[\u005A\u24CF\uFF3A\u0179\u1E90\u017B\u017D\u1E92\u1E94\u01B5\u0224\u2C7F\u2C6B\uA762]/g },
        { 'base': 'a', 'letters': /[\u0061\u24D0\uFF41\u1E9A\u00E0\u00E1\u00E2\u1EA7\u1EA5\u1EAB\u1EA9\u00E3\u0101\u0103\u1EB1\u1EAF\u1EB5\u1EB3\u0227\u01E1\u00E4\u01DF\u1EA3\u00E5\u01FB\u01CE\u0201\u0203\u1EA1\u1EAD\u1EB7\u1E01\u0105\u2C65\u0250]/g },
        { 'base': 'aa', 'letters': /[\uA733]/g },
        { 'base': 'ae', 'letters': /[\u00E6\u01FD\u01E3]/g },
        { 'base': 'ao', 'letters': /[\uA735]/g },
        { 'base': 'au', 'letters': /[\uA737]/g },
        { 'base': 'av', 'letters': /[\uA739\uA73B]/g },
        { 'base': 'ay', 'letters': /[\uA73D]/g },
        { 'base': 'b', 'letters': /[\u0062\u24D1\uFF42\u1E03\u1E05\u1E07\u0180\u0183\u0253]/g },
        { 'base': 'c', 'letters': /[\u0063\u24D2\uFF43\u0107\u0109\u010B\u010D\u00E7\u1E09\u0188\u023C\uA73F\u2184]/g },
        { 'base': 'd', 'letters': /[\u0064\u24D3\uFF44\u1E0B\u010F\u1E0D\u1E11\u1E13\u1E0F\u0111\u018C\u0256\u0257\uA77A]/g },
        { 'base': 'dz', 'letters': /[\u01F3\u01C6]/g },
        { 'base': 'e', 'letters': /[\u0065\u24D4\uFF45\u00E8\u00E9\u00EA\u1EC1\u1EBF\u1EC5\u1EC3\u1EBD\u0113\u1E15\u1E17\u0115\u0117\u00EB\u1EBB\u011B\u0205\u0207\u1EB9\u1EC7\u0229\u1E1D\u0119\u1E19\u1E1B\u0247\u025B\u01DD]/g },
        { 'base': 'f', 'letters': /[\u0066\u24D5\uFF46\u1E1F\u0192\uA77C]/g },
        { 'base': 'g', 'letters': /[\u0067\u24D6\uFF47\u01F5\u011D\u1E21\u011F\u0121\u01E7\u0123\u01E5\u0260\uA7A1\u1D79\uA77F]/g },
        { 'base': 'h', 'letters': /[\u0068\u24D7\uFF48\u0125\u1E23\u1E27\u021F\u1E25\u1E29\u1E2B\u1E96\u0127\u2C68\u2C76\u0265]/g },
        { 'base': 'hv', 'letters': /[\u0195]/g },
        { 'base': 'i', 'letters': /[\u0069\u24D8\uFF49\u00EC\u00ED\u00EE\u0129\u012B\u012D\u00EF\u1E2F\u1EC9\u01D0\u0209\u020B\u1ECB\u012F\u1E2D\u0268\u0131]/g },
        { 'base': 'j', 'letters': /[\u006A\u24D9\uFF4A\u0135\u01F0\u0249]/g },
        { 'base': 'k', 'letters': /[\u006B\u24DA\uFF4B\u1E31\u01E9\u1E33\u0137\u1E35\u0199\u2C6A\uA741\uA743\uA745\uA7A3]/g },
        { 'base': 'l', 'letters': /[\u006C\u24DB\uFF4C\u0140\u013A\u013E\u1E37\u1E39\u013C\u1E3D\u1E3B\u017F\u0142\u019A\u026B\u2C61\uA749\uA781\uA747]/g },
        { 'base': 'lj', 'letters': /[\u01C9]/g },
        { 'base': 'm', 'letters': /[\u006D\u24DC\uFF4D\u1E3F\u1E41\u1E43\u0271\u026F]/g },
        { 'base': 'n', 'letters': /[\u006E\u24DD\uFF4E\u01F9\u0144\u00F1\u1E45\u0148\u1E47\u0146\u1E4B\u1E49\u019E\u0272\u0149\uA791\uA7A5]/g },
        { 'base': 'nj', 'letters': /[\u01CC]/g },
        { 'base': 'o', 'letters': /[\u006F\u24DE\uFF4F\u00F2\u00F3\u00F4\u1ED3\u1ED1\u1ED7\u1ED5\u00F5\u1E4D\u022D\u1E4F\u014D\u1E51\u1E53\u014F\u022F\u0231\u00F6\u022B\u1ECF\u0151\u01D2\u020D\u020F\u01A1\u1EDD\u1EDB\u1EE1\u1EDF\u1EE3\u1ECD\u1ED9\u01EB\u01ED\u00F8\u01FF\u0254\uA74B\uA74D\u0275]/g },
        { 'base': 'oi', 'letters': /[\u01A3]/g },
        { 'base': 'ou', 'letters': /[\u0223]/g },
        { 'base': 'oo', 'letters': /[\uA74F]/g },
        { 'base': 'p', 'letters': /[\u0070\u24DF\uFF50\u1E55\u1E57\u01A5\u1D7D\uA751\uA753\uA755]/g },
        { 'base': 'q', 'letters': /[\u0071\u24E0\uFF51\u024B\uA757\uA759]/g },
        { 'base': 'r', 'letters': /[\u0072\u24E1\uFF52\u0155\u1E59\u0159\u0211\u0213\u1E5B\u1E5D\u0157\u1E5F\u024D\u027D\uA75B\uA7A7\uA783]/g },
        { 'base': 's', 'letters': /[\u0073\u24E2\uFF53\u00DF\u015B\u1E65\u015D\u1E61\u0161\u1E67\u1E63\u1E69\u0219\u015F\u023F\uA7A9\uA785\u1E9B]/g },
        { 'base': 't', 'letters': /[\u0074\u24E3\uFF54\u1E6B\u1E97\u0165\u1E6D\u021B\u0163\u1E71\u1E6F\u0167\u01AD\u0288\u2C66\uA787]/g },
        { 'base': 'tz', 'letters': /[\uA729]/g },
        { 'base': 'u', 'letters': /[\u0075\u24E4\uFF55\u00F9\u00FA\u00FB\u0169\u1E79\u016B\u1E7B\u016D\u00FC\u01DC\u01D8\u01D6\u01DA\u1EE7\u016F\u0171\u01D4\u0215\u0217\u01B0\u1EEB\u1EE9\u1EEF\u1EED\u1EF1\u1EE5\u1E73\u0173\u1E77\u1E75\u0289]/g },
        { 'base': 'v', 'letters': /[\u0076\u24E5\uFF56\u1E7D\u1E7F\u028B\uA75F\u028C]/g },
        { 'base': 'vy', 'letters': /[\uA761]/g },
        { 'base': 'w', 'letters': /[\u0077\u24E6\uFF57\u1E81\u1E83\u0175\u1E87\u1E85\u1E98\u1E89\u2C73]/g },
        { 'base': 'x', 'letters': /[\u0078\u24E7\uFF58\u1E8B\u1E8D]/g },
        { 'base': 'y', 'letters': /[\u0079\u24E8\uFF59\u1EF3\u00FD\u0177\u1EF9\u0233\u1E8F\u00FF\u1EF7\u1E99\u1EF5\u01B4\u024F\u1EFF]/g },
        { 'base': 'z', 'letters': /[\u007A\u24E9\uFF5A\u017A\u1E91\u017C\u017E\u1E93\u1E95\u01B6\u0225\u0240\u2C6C\uA763]/g }
    ];

    for (var i = 0; i < defaultDiacriticsRemovalMap.length; i++) {
        str = str.replace(defaultDiacriticsRemovalMap[i].letters, defaultDiacriticsRemovalMap[i].base);
    }

    return str;

}
/**
 * Funcion que realiza un formateo sobre la fecha entregada por Netsuite en el proceso de recuperacion de la
 * informacion para la creacion del XML del postdata
 * @param {String}date String de la fecha que se va a formatear, se recibe el formato d/m/yyyy
 * @returns {String} Entrega la fecha con el siguiente formato yyyy-mm-dd
 */
function formatingDate(date) {
    var arrDate = date.split('/');
    var strDateFinal = arrDate[2];
    if (arrDate[1].length < 2) {
        strDateFinal = strDateFinal + '-0' + arrDate[1];
    } else {
        strDateFinal = strDateFinal + '-' + arrDate[1];
    }
    if (arrDate[0].length < 2) {
        strDateFinal = strDateFinal + '-0' + arrDate[0];
    } else {
        strDateFinal = strDateFinal + '-' + arrDate[0];
    }
    return strDateFinal;
}
/**
 * Funcion que formatea el tipo de moneda de acuerdo a lo recibido por el servicio de bizlinks
 * @param {String}currency String del tipo de moneda en Netsuite
 * @returns {String} Entrega el String de la moneda de acuerdo a lo requerido por el servicio de bizlinks,
 * el servicio web maneja la siguien conversion.
 * Soles=PEN
 * Dolares Americanos = USD
 */
function formatingCurrency(currency) {
    nlapiLogExecution('DEBUG', 'Currency', currency);
    var method = 'formatingCurrency';
    var strCurrency = '';
    try {
        var filters = new Array();
        filters.push(new nlobjSearchFilter('custrecord_ks_pe_currency_setup', null, 'is', currency));
        var columns = new Array();
        columns[0] = new nlobjSearchColumn('custrecord_ks_pe_simbolo_sunat')
        var searchresults = nlapiSearchRecord('customrecord_ks_pe_currency_setup', null, filters, columns);
        if (searchresults) {
            for (var i = 0; i < searchresults.length; i++) {
                strCurrency = searchresults[i].getValue(columns[0]);
            }
        }
    } catch (e) {
        nlapiLogExecution('ERROR', method, e)
    }
    nlapiLogExecution('DEBUG', 'Currency', 'found::' + strCurrency);
    return strCurrency;
}
/**
 * Funcion que recupera el numeor de identificacion del cliente vatregnumber
 * @param {String|Number}internalIdCliente Id interno del cliente del cual se desea saber la identificaion
 * @returns {String|Number} Entrega el numero de identificacion del cliente
 */
function getIDCliente(internalIdCliente) {
    var strIdCliente = nlapiLookupField('customer', internalIdCliente, 'vatregnumber');
    return strIdCliente;
}


function addUnitsSUNAT() {
    var searchresults = nlapiSearchRecord(null, 'customsearch_ks_pe_unidades_bizlinks', null, null);
    if (searchresults) {
        for (var each = 0; each < searchresults.length; each++) {
            var record = searchresults[each];
            var columns = record.getAllColumns();
            unidadesSunat[record.getValue(columns[2]) + '_' + record.getValue(columns[0])] = record.getText(columns[1]);
        }
    }

}

function buildAddress(subsidiary) {
    var method = 'buildAddress';
    var xmlStructure = '';
    try {
        var filters = new Array();
        filters.push(new nlobjSearchFilter('internalid', null, 'is', subsidiary));
        var searchresults = nlapiSearchRecord('subsidiary', 'customsearch_ks_pe_subsidiary_address_ei', filters, null);
        if (searchresults) {
            for (var i = 0; i < searchresults.length; i++) {
                var columns = searchresults[i].getAllColumns();
                xmlStructure = xmlStructure + '<ubigeoEmisor>150122</ubigeoEmisor>';
                xmlStructure = xmlStructure + '<direccionEmisor>' + searchresults[i].getValue(columns[6]) + '</direccionEmisor>';
                xmlStructure = xmlStructure + '<provinciaEmisor>' + searchresults[i].getValue(columns[7]) + '</provinciaEmisor>';
                xmlStructure = xmlStructure + '<departamentoEmisor>' + searchresults[i].getValue(columns[2]) + '</departamentoEmisor>';
                xmlStructure = xmlStructure + '<distritoEmisor>' + searchresults[i].getValue(columns[8]) + '</distritoEmisor>';
                xmlStructure = xmlStructure + '<paisEmisor>PE</paisEmisor>';
                xmlStructure = xmlStructure + '<correoEmisor>-</correoEmisor>';
            }
        }

    } catch (e) {
        nlapiLogExecution('ERROR', method, e)
    }
    return xmlStructure;
}

function removeDiacritics(str) {

    var defaultDiacriticsRemovalMap = [
        { 'base': '&#38;', 'letters': /&/g },
        { 'base': '&#162;', 'letters': /¢/g },
        { 'base': '&#163;', 'letters': /£/g },
        { 'base': '&#164;', 'letters': /¤/g },
        { 'base': '&#165;', 'letters': /¥/g },
        { 'base': '&#166;', 'letters': /¦/g },
        { 'base': '&#167;', 'letters': /§/g },
        { 'base': '&#168;', 'letters': /¨/g },
        { 'base': '&#169;', 'letters': /©/g },
        { 'base': '&#170;', 'letters': /ª/g },
        { 'base': '&#171;', 'letters': /«/g },
        { 'base': '&#172;', 'letters': /¬/g },
        { 'base': '&#174;', 'letters': /®/g },
        { 'base': '&#175;', 'letters': /¯/g },
        { 'base': '&#176;', 'letters': /°/g },
        { 'base': '&#177;', 'letters': /±/g },
        { 'base': '&#178;', 'letters': /²/g },
        { 'base': '&#179;', 'letters': /³/g },
        { 'base': '&#180;', 'letters': /´/g },
        { 'base': '&#181;', 'letters': /µ/g },
        { 'base': '&#182;', 'letters': /¶/g },
        { 'base': '&#183;', 'letters': /·/g },
        { 'base': '&#184;', 'letters': /¸/g },
        { 'base': '&#185;', 'letters': /¹/g },
        { 'base': '&#186;', 'letters': /º/g },
        { 'base': '&#187;', 'letters': /»/g },
        { 'base': '&#188;', 'letters': /¼/g },
        { 'base': '&#64;', 'letters': /@/g },
        { 'base': '&#189;', 'letters': /½/g },
        { 'base': '&#190;', 'letters': /¾/g },
        { 'base': '&#191;', 'letters': /¿/g },
        { 'base': '&#209;', 'letters': /Ñ/g },
        { 'base': '&#192;', 'letters': /À/g },
        { 'base': '&#193;', 'letters': /Á/g },
        { 'base': '&#194;', 'letters': /Â/g },
        { 'base': '&#195;', 'letters': /Ã/g },
        { 'base': '&#196;', 'letters': /Ä/g },
        { 'base': '&#197;', 'letters': /Å/g },
        { 'base': '&#198;', 'letters': /Æ/g },
        { 'base': '&#199;', 'letters': /Ç/g },
        { 'base': '&#200;', 'letters': /È/g },
        { 'base': '&#201;', 'letters': /É/g },
        { 'base': '&#202;', 'letters': /Ê/g },
        { 'base': '&#203;', 'letters': /Ë/g },
        { 'base': '&#204;', 'letters': /Ì/g },
        { 'base': '&#205;', 'letters': /Í/g },
        { 'base': '&#206;', 'letters': /Î/g },
        { 'base': '&#207;', 'letters': /Ï/g },
        { 'base': '&#208;', 'letters': /Ð/g },
        { 'base': '&#209;', 'letters': /Ñ/g },
        { 'base': '&#210;', 'letters': /Ò/g },
        { 'base': '&#211;', 'letters': /Ó/g },
        { 'base': '&#212;', 'letters': /Ô/g },
        { 'base': '&#213;', 'letters': /Õ/g },
        { 'base': '&#214;', 'letters': /Ö/g },
        { 'base': '&#215;', 'letters': /×/g },
        { 'base': '&#216;', 'letters': /Ø/g },
        { 'base': '&#217;', 'letters': /Ù/g },
        { 'base': '&#218;', 'letters': /Ú/g },
        { 'base': '&#219;', 'letters': /Û/g },
        { 'base': '&#220;', 'letters': /Ü/g },
        { 'base': '&#221;', 'letters': /Ý/g },
        { 'base': '&#222;', 'letters': /Þ/g },
        { 'base': '&#223;', 'letters': /ß/g },
        { 'base': '&#224;', 'letters': /à/g },
        { 'base': '&#225;', 'letters': /á/g },
        { 'base': '&#226;', 'letters': /â/g },
        { 'base': '&#227;', 'letters': /ã/g },
        { 'base': '&#228;', 'letters': /ä/g },
        { 'base': '&#229;', 'letters': /å/g },
        { 'base': '&#230;', 'letters': /æ/g },
        { 'base': '&#231;', 'letters': /ç/g },
        { 'base': '&#232;', 'letters': /è/g },
        { 'base': '&#233;', 'letters': /é/g },
        { 'base': '&#234;', 'letters': /ê/g },
        { 'base': '&#235;', 'letters': /ë/g },
        { 'base': '&#236;', 'letters': /ì/g },
        { 'base': '&#237;', 'letters': /í/g },
        { 'base': '&#238;', 'letters': /î/g },
        { 'base': '&#239;', 'letters': /ï/g },
        { 'base': '&#240;', 'letters': /ð/g },
        { 'base': '&#241;', 'letters': /ñ/g },
        { 'base': '&#242;', 'letters': /ò/g },
        { 'base': '&#243;', 'letters': /ó/g },
        { 'base': '&#244;', 'letters': /ô/g },
        { 'base': '&#245;', 'letters': /õ/g },
        { 'base': '&#246;', 'letters': /ö/g },
        { 'base': '&#247;', 'letters': /÷/g },
        { 'base': '&#248;', 'letters': /ø/g },
        { 'base': '&#249;', 'letters': /ù/g },
        { 'base': '&#250;', 'letters': /ú/g },
        { 'base': '&#251;', 'letters': /û/g },
        { 'base': '&#252;', 'letters': /ü/g },
        { 'base': '&#253;', 'letters': /ý/g },
        { 'base': '&#254;', 'letters': /þ/g },
        { 'base': '&#255;', 'letters': /ÿ/g },
        { 'base': '&#8215;', 'letters': /‗/g },
        { 'base': '&#8216;', 'letters': /‘/g },
        { 'base': '&#8217;', 'letters': /’/g },
        { 'base': '&#8218;', 'letters': /‚/g },
        { 'base': '&#8219;', 'letters': /‛/g },
        { 'base': '&#8222;', 'letters': /„/g },
        { 'base': '&#8224;', 'letters': /†/g },
        { 'base': '&#8225;', 'letters': /‡/g },
        { 'base': '&#8226;', 'letters': /•/g },
        { 'base': '&#8230', 'letters': /…/g },
        { 'base': '&#8240;', 'letters': /‰/g },
        { 'base': '&#8242;', 'letters': /′/g },
        { 'base': '&#8243;', 'letters': /″/g },
        { 'base': '&#8252;', 'letters': /‼/g },
        { 'base': '&#8254;', 'letters': /‾/g },
        { 'base': '&#8260;', 'letters': /⁄/g },
    ];

    for (var i = 0; i < defaultDiacriticsRemovalMap.length; i++) {
        str = str.replace(defaultDiacriticsRemovalMap[i].letters, defaultDiacriticsRemovalMap[i].base);
    }

    return str;

}