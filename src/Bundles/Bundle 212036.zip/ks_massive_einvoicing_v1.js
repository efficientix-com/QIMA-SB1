/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       24 Oct 2017     JuanKIS
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function ks_massive_einvoicng(type) {
    var method = 'ks_massive_einvoicng';
    try {
        var context = nlapiGetContext();
        var originsearch = context.getSetting('SCRIPT', 'custscript_ks_pe_busqueda_base');
        nlapiLogExecution('ERROR', 'originsearch', originsearch)
        var script = context.getScriptId();
        var deploy = context.getDeploymentId();
        var searchresults = nlapiSearchRecord(null, originsearch, null, null);

        nlapiLogExecution('ERROR', 'searchresults.length', searchresults.length)

        if (searchresults) {
            nlapiLogExecution('AUDIT', method, 'Total Records:: ' + searchresults.length);
            for (var i = 0; i < searchresults.length; i++) {
                var record = searchresults[i];
                var columns = record.getAllColumns();
                var idinv = record.getValue(columns[0]);
                var type = record.getValue(columns[2]);
                var subsidiary = record.getValue(columns[3]);
                nlapiLogExecution('AUDIT', method, idinv + ':: ' + type);
                if (type == 'CustInvc') {
                    callBizlinks(idinv, '1', subsidiary);
                } else {
                    callBizlinks(idinv, '3', subsidiary);
                }
            }
        }
        nlapiScheduleScript(script, deploy);
    } catch (e) {
        nlapiLogExecution('ERROR', method, e)
    }
}