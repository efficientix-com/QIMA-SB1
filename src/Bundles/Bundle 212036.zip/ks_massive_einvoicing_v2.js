/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       24 Oct 2017     JuanKIS
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function ks_massive_einvoicng(type) {
    var method = 'ks_massive_einvoicng';
    try {
        var context = nlapiGetContext();
        var originsearch = context.getSetting('SCRIPT', 'custscript_ks_fe_busqueda');
        var defaultSubsidiary = context.getSetting('SCRIPT', 'custscript_ks_subsidiary_pe');
        var script = context.getScriptId();
        var deploy = context.getDeploymentId();
        if (deploy == 'customdeploy_ks_envio_periodico_21' || deploy == 'customdeploy_ks_deply_on_demand') {
            var searchresults = nlapiSearchRecord(null, originsearch, null, null);
            if (searchresults) {
                nlapiLogExecution('AUDIT', method, 'Total Records:: ' + searchresults.length);
                for (var i = 0; i < 21; i++) {
                    nlapiLogExecution('AUDIT', method, 'transaction number: ' + i);
                    var record = searchresults[i];
                    var columns = record.getAllColumns();
                    var idinv = record.getValue(columns[0]);
                    var type = record.getValue(columns[2]);
                    var subsidiary = record.getValue(columns[3]);
                    nlapiLogExecution('AUDIT', method, idinv + ':: ' + type);
                    if (type == 'invoice' || type == 'CustInvc') {
                        callBizlinks(idinv, '1', subsidiary);
                    } else if (type == 'cashsale') {
                        callBizlinks(idinv, 'cashsale', subsidiary);
                    } else {
                        callBizlinks(idinv, '3', subsidiary);
                    }
                    nlapiLogExecution('AUDIT', method, 'type: ' + type);
                    nlapiLogExecution('AUDIT', method, 'idinv: ' + idinv);
                }
                //nlapiScheduleScript(script, deploy);
            }
            if (deploy == 'customdeploy_ks_envio_periodico_21'){
                var status = nlapiScheduleScript(script, deploy, null);
                return status;
            } 
        } else if (deploy == 'customdeploy_ks_scheduled_einvoicing') {
            callBizlinks(1, '4', defaultSubsidiary);
        } else if (deploy == 'customdeploy_ks_pe_consulta_comprobantes') {
            var searchresults = nlapiSearchRecord(null, originsearch, null, null);
            if (searchresults) {
                nlapiLogExecution('DEBUG', method, 'Total Records a consultar:: ' + searchresults.length);
                for (var i = 0; i < searchresults.length; i++) {
                    try {
                        var remainingUsage = context.getRemainingUsage();
                        nlapiLogExecution('AUDIT', method, 'Creditos restantes: ' + remainingUsage);
                        if (remainingUsage <= 400) {
                            nlapiScheduleScript(script, deploy);
                          	return;
                        } else {
                            var record = searchresults[i];
                            var columns = record.getAllColumns();
                            var id_tran = record.getValue(columns[0]);
                            var type = record.getValue(columns[2]);
                            var subsidiary = record.getValue(columns[3]);
                            var doc_type = record.getValue(columns[4]);
                            var serie = record.getValue(columns[5]);
                            var correlativo = record.getValue(columns[6]);
                            nlapiLogExecution('AUDIT', method, idinv + ':: ' + type);
                            consultBizlinks(id_tran, type, '7', subsidiary, doc_type, serie, correlativo);
                        }
                    } catch (e) {
                        var mensajeError = e.valueOf().toString();
                        nlapiLogExecution('ERROR', method, mensajeError);
                    }
                }
            }
        } else if (deploy == 'customdeploy_ks_pe_consulta_rd') {
            var searchresults = nlapiSearchRecord(null, originsearch, null, null);
            if (searchresults) {
                nlapiLogExecution('DEBUG', method, 'Total Records a consultar:: ' + searchresults.length);
                for (var i = 0; i < searchresults.length; i++) {
                    try {
                        var remainingUsage = context.getRemainingUsage();
                        nlapiLogExecution('DEBUG', method, 'Creditos restantes: ' + remainingUsage);
                        if (remainingUsage <= 400) {
                            nlapiScheduleScript(script, deploy);
                          	return;
                        } else {
                            var record = searchresults[i];
                            var columns = record.getAllColumns();
                            var id_rd = record.getValue(columns[0]);
                            var nombre_rd = record.getValue(columns[1]);
                            var subsidiary = record.getValue(columns[2]);
                            var type = 'customrecord_ks_pe_resumen_comprobantes';
                            nlapiLogExecution('DEBUG', method, id_rd + ':: ' + nombre_rd);
                            consultBizlinks(id_rd, type, '8', subsidiary, nombre_rd);
                        }
                    } catch (e) {
                        var mensajeError = e.valueOf().toString();
                        nlapiLogExecution('ERROR', method, mensajeError);
                    }
                }
            }
        }
        nlapiLogExecution('DEBUG', method, 'deploy: ' + deploy)
    } catch (e) {
        nlapiLogExecution('ERROR', method, e)
    }
}