/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */

/**
 * Module Description
 * 
 * Name       KS UE Electronic Invoicing ADV
 * Version    Date            Author            Modification
 * 1.00       20 October 2021     Danilo Steven   Functions:    
 *
 */

define(['N/log', 'N/record', 'N/runtime', 'N/format', 'N/search'], function(log, record, runtime, format, search) {

    var SETUP = {
        SEARCH: {
            TAX_CODE_SETUP: 'customsearch_ks_pe_tax_code_setup',
        },
        TAX_TYPE: {
            IGV: 1,
            ISC: 2
        }
    }

    var IGV_TOTAL = 0;
    var ISC_TOTAL = 0;

    function beforeLoad(context) {
       
    }

    function beforeSubmit(context) {
        var type = context.type;
        var newRecord = context.newRecord;
        var recType = newRecord.type;
        var recId = newRecord.id;

        var method = 'beforeSubmit'
        log.debug({ title: method, details: 'Working for Type: ' + recType + ' Record ID: ' + recId + ' type: ' + type + ' Init..' })
        if (type == 'create' || type == 'edit') {

            var filters = [];
            var taxCodeSetup = customSearch({ search: SETUP.SEARCH.TAX_CODE_SETUP, filters: filters });
            var taxCodeSetupObj = {}
            if (taxCodeSetup.length > 0 && taxCodeSetup) {
                taxCodeSetupObj = arrayToObject(taxCodeSetup, 'taxCodeId');
            }
            var igvTotal = 0;
            var iscTotal = 0;

            //Getting Line Data
            var itemLinesNumber = newRecord.getLineCount({ sublistId: 'item' })
            log.debug({ title: method, details: 'Item Lines: ' + itemLinesNumber })
            for (var i = 0; i < itemLinesNumber; i++) {

                var taxcode = newRecord.getSublistValue({ sublistId: 'item', fieldId: 'taxcode', line: i });
                var amount = newRecord.getSublistValue({ sublistId: 'item', fieldId: 'amount', line: i });
                var item = newRecord.getSublistValue({ sublistId: 'item', fieldId: 'item', line: i });
                var taxline = newRecord.getSublistValue({ sublistId: 'item', fieldId: 'istaxable', line: i });
                var istaxline = newRecord.getSublistValue({ sublistId: 'item', fieldId: 'custcol_4601_witaxline', line: i });
                var whTaxCode = newRecord.getSublistValue({ sublistId: 'item', fieldId: 'custcol_4601_witaxcode', line: i });

                var taxCodeData = taxCodeSetupObj[taxcode];
                log.debug({ title: method, details: 'Tax Code: ' + JSON.stringify(taxcode) })
                log.debug({ title: method, details: 'Tax Code Data: ' + JSON.stringify(taxCodeData) })

                if (taxCodeData != undefined) {
                    var rate = parseFloat(taxCodeData.rate.replace('%', ''))
                    if (taxCodeData.type == SETUP.TAX_TYPE.IGV) {
                        igvTotal += (amount * parseFloat(rate / 100));
                    } else if (taxCodeData.type == SETUP.TAX_TYPE.ISC) {
                        iscTotal += (amount * parseFloat(rate / 100));
                    }
                }

            }

            //Setting Values
            igvTotal = igvTotal.toFixed(2);
            iscTotal = iscTotal.toFixed(2);
            log.debug({ title: method, details: 'igvTotal: ' + igvTotal + ' iscTotal: ' + iscTotal })
            newRecord.setValue({ fieldId: 'custbody_ks_pe_total_igv', value: igvTotal, ignoreFieldChange: true })
            newRecord.setValue({ fieldId: 'custbody_ks_pe_total_isc', value: iscTotal, ignoreFieldChange: true })
        }

    }

    function afterSubmit(context) {
        var type = context.type;
        var newRecord = context.newRecord;
        var recType = newRecord.type;
        var recId = newRecord.id;

        var method = 'afterSubmit'
        log.debug({ title: method, details: 'Working for Type: ' + recType + ' Record ID: ' + recId + ' type: ' + type + ' Init..' })
        if ((type == 'create' || type == 'edit') && recType == 'invoice') {
            var total = newRecord.getValue('total');
            var detra = newRecord.getValue('custbody_kspe_concepto_de_detraccion');
            var detraRate = newRecord.getValue('custbody_ks_porcentaje_de_detraccion');
            var exchangeType = parseFloat(newRecord.getValue('exchangerate'));
            var currency = newRecord.getValue('currencysymbol');
            log.debug(method, 'detraRate: ' + detraRate + ' - ' + typeof(detraRate));
            var detractionAmount = 0;
            var detractionAmountCuota = 0;
            if (detra && detraRate > 0) {
                // if (currency != 'PEN') {
                //     detractionAmount = total * detraRate / 100;
                //     body = body.replace('-detractionAmount-', Math.round(detractionAmount * exchangeType));
                // } else {
                //     detractionAmount = Math.round(total * detraRate / 100);
                //     body = body.replace('-detractionAmount-', detractionAmount);
                // }
                detractionAmount = (total * detraRate / 100) * exchangeType;
                log.debug('detractionAmount', Math.round(detractionAmount));

                record.submitFields({
                    type: recType,
                    id: newRecord.id,
                    values: {
                        'custbody_ks_monto_detraccion': Math.round(detractionAmount)
                    },
                    options: {
                        ignoreMandatoryFields: true,
                        enableSourcing: true,
                        disableTriggers: true
                    }
                });
            }
        }

    }

    /**
     * 
     * Creates or Loads the required Saved Search, 
     * @param {Object} param - search Parameters Id, Filters, etc.
     * @returns {Array} - Returns the search result in an Array with the name of the elments according to the search column label
     */
    function customSearch(param) {
        var method = 'customSearch';
        var response = [];
        var columns = [];
        var filters = [];
        try {

            if (param.search && param.search != '') {
                var searchDetails = search.load({
                    id: param.search,
                    type: param.type ? param.type : null
                });
                filters = searchDetails.filters;
            }
            if (param.filters) {
                for (var i = 0; i < param.filters.length; i++) {
                    filters.push(param.filters[i]);
                }
            }
            if (param.columns) {
                for (var i = 0; i < param.columns.length; i++) {
                    columns.push(param.columns[i]);
                }
            }
            if (!searchDetails) {
                var searchDetails = search.create({
                    type: param.type ? param.type : null,
                    columns: columns,
                    filters: filters
                });
            }
            var searchDetailsResults = searchDetails.run().getRange({
                start: param.start ? param.start : 0,
                end: param.end ? param.end : 1000
            });
            if (searchDetailsResults.length > 0) {
                var detailResult = searchDetailsResults[0];
                var columns = detailResult.columns;
                for (var i = 0; i < searchDetailsResults.length; i++) {
                    var responseObj = {};
                    var detailResult = searchDetailsResults[i];
                    for (var j = 0; j < columns.length; j++) {
                        responseObj[columns[j].label] = detailResult.getValue(columns[j]);
                    }
                    response.push(responseObj);
                }
            }
            log.debug({ title: method, details: 'response: ' + JSON.stringify(response) });
            return response;
        } catch (error) {
            log.error({ title: method, details: error })
        }
    }


    /**
     * 
     * Transforms an Array to Object
     * @param {Object} array - a vnormal and ordinary Array.
     * @param {Object} array - a key or property in the array
     * @returns {Array} - an object base in the input array
     */
    function arrayToObject(array, keyK) {
        try {
            var method = 'arrayToObject'
            var result = {};
            for (var i = 0; i < array.length; i++) {
                result[array[i][keyK]] = array[i];
            }
            log.debug({ title: method, details: 'keyK: ' + keyK + ' result' + JSON.stringify(result) });
            return result;
        } catch (error) {
            log.error({ title: method, details: error })
        }
    }

    return {
        beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    }
});