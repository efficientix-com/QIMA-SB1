	/**
	 * @NApiVersion 2.x
	 * @NScriptType UserEventScript
	 * @NModuleScope SameAccount
	 */
	define(['N/record',
	        'N/runtime',
	        'N/search',
	        'N/log',
	        'N/ui/serverWidget'],
	function(record,runtime,search,log,serverWidget) {
	   var CATALOGO_7 =new Object();
	   CATALOGO_7.GRAVADO_OPERACION_ONEROSA=106;
	   CATALOGO_7.INAFECTO_OPERACION_ONEROSA=113;
	   CATALOGO_7.EXONERADO_OPERACION_ONEROSA=101;
	   CATALOGO_7.GRAVADO_BONIFICACION=104;
	   CATALOGO_7.EXONERADO_GRATUITA=102;
	   var CATALOGO_5 =new Object();
	   CATALOGO_5.IGV=4;
	   CATALOGO_5.EXONERADO=1;
	   CATALOGO_5.INAFECTO=6;
	   CATALOGO_5.GRATUITO=3;
	   var CATALOGO_17 =new Object();
	   CATALOGO_17.VENTA_INTERNA=18;
	   CATALOGO_17.EXPORTACION=2;
	   var CATALOGO_51 =new Object();
	   CATALOGO_51.VENTA_INTERNA=1;
		    /**
		     * Function definition to be triggered before record is loaded.
		     *
		     * @param {Object} scriptContext
		     * @param {Record} scriptContext.newRecord - New record
		     * @param {string} scriptContext.type - Trigger type
		     * @param {Form} scriptContext.form - Current form
		     * @Since 2015.2
		     */
		    function beforeLoad(scriptContext) {
		    }
		    /**
		     * Function definition to be triggered before record is loaded.
		     *
		     * @param {Object} scriptContext
		     * @param {Record} scriptContext.newRecord - New record
		     * @param {Record} scriptContext.oldRecord - Old record
		     * @param {string} scriptContext.type - Trigger type
		     * @Since 2015.2
		     */
		    function beforeSubmit(scriptContext) {
		    }
		
		    /**
		     * Function definition to be triggered before record is loaded.
		     *
		     * @param {Object} scriptContext
		     * @param {Record} scriptContext.newRecord - New record
		     * @param {Record} scriptContext.oldRecord - Old record
		     * @param {string} scriptContext.type - Trigger type
		     * @Since 2015.2
		     */
		    function afterSubmit(scriptContext) {
			var method = 'fe_on_invoice.afterSubmit';
			var type = scriptContext.type;
			var newRecord = scriptContext.newRecord;
			var oldRecord = scriptContext.oldRecord;
			var recType = newRecord.type;
			var recId = newRecord.id;
			try{
					
				if(type=='create' || type=='edit'){
					var currentRecord = record.load({type: recType, id: recId});
					var taxtotal = currentRecord.getValue({fieldId: 'taxtotal'});
					var script = runtime.getCurrentScript();
					var campoGratuita = script.getParameter({name: 'custscript_ks_campo_gratuita'});
					var gratuita = currentRecord.getValue({fieldId: campoGratuita});
					log.debug({title: method,details:taxtotal+'::'+gratuita});
					if(gratuita==true){
						if(parseFloat(taxtotal)>0){
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_7_v2',value:CATALOGO_7.GRAVADO_OPERACION_ONEROSA});
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_5_v2',value:CATALOGO_5.IGV});
							var joinCatalog = getCatalogValue(CATALOGO_5.IGV,CATALOGO_7.GRAVADO_OPERACION_ONEROSA);
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_5_vs_7',value:joinCatalog});
						}else{
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_7_v2',value:CATALOGO_7.EXONERADO_OPERACION_ONEROSA})
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_5_v2',value:CATALOGO_5.EXONERADO});
							var joinCatalog = getCatalogValue(CATALOGO_5.EXONERADO,CATALOGO_7.EXONERADO_OPERACION_ONEROSA);
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_5_vs_7',value:joinCatalog});
						}
					}else{
						if(parseFloat(taxtotal)>0){
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_7_v2',value:CATALOGO_7.GRAVADO_OPERACION_ONEROSA});
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_5_v2',value:CATALOGO_5.IGV});
							var joinCatalog = getCatalogValue(CATALOGO_5.IGV,CATALOGO_7.GRAVADO_OPERACION_ONEROSA);
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_5_vs_7',value:joinCatalog});
						}else{
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_7_v2',value:CATALOGO_7.EXONERADO_OPERACION_ONEROSA})
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_5_v2',value:CATALOGO_5.EXONERADO});
							var joinCatalog = getCatalogValue(CATALOGO_5.EXONERADO,CATALOGO_7.EXONERADO_OPERACION_ONEROSA);
							currentRecord.setValue({fieldId:'custbody_ps001_catalogo_5_vs_7',value:joinCatalog});
						}
					}
					currentRecord.setValue({fieldId:'custbody_ks_catalogo_51_tipo_op',value:CATALOGO_51.VENTA_INTERNA});
					currentRecord.setValue({fieldId:'custbody_ps001_catalogo_17_tipo_op',value:CATALOGO_17.VENTA_INTERNA});
					currentRecord.save();
				}
				
			}catch(e){
				log.error({title: method,details:e});
			}
		;
	    }
	    function getCatalogValue(cat5,cat7){
	    	var method = 'getCatalogValue';
	    	var joincatalogid = null;
	    	try{
	    		var filters = new Array();
				filters.push( search.createFilter({
					name: 'custrecord_ps001_catalogo_5',
					operator: search.Operator.IS,
					values:cat5
				}));
				filters.push( search.createFilter({
					name: 'custrecord_ps001_catalogo_7',
					operator: search.Operator.IS,
					values:cat7
				}));
				var linesSearch = search.load({
					id: 'customsearch_ps001_cat5_vs_cat7'
				});
				linesSearch.filters=filters;
				var searchResult = linesSearch.run().getRange({start: 0,end: 1000});
				for (var i = 0; i < searchResult.length; i++) {
					var columns=searchResult[i].columns;
					joincatalogid = searchResult[i].getValue(columns[0])
				}
	    	}catch(e){
	    		log.error({title: method,details:e});
	    	}
	    	return joincatalogid;
	    }
	    return {
	        beforeLoad: beforeLoad,
	        beforeSubmit: beforeSubmit,
	        afterSubmit: afterSubmit
	    };
	    
	});
