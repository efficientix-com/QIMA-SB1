/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       02 Nov 2017     Keep-Simple
 *
 */
function KS_AWT_userEvent(){}
/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit
 *                      approve, reject, cancel (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF)
 *                      markcomplete (Call, Task)
 *                      reassign (Case)
 *                      editforecast (Opp, Estimate)
 * @returns {Void}
 */

KS_AWT_userEvent.afterSubmit = function(strSubsidiary,strCurrency,strTransactionType,strTotal,recId,recType) {
	var method = 'KS_AWT_userEvent.afterSubmit';
	
	try{
		// var strSubsidiary = nlapiGetFieldValue("subsidiary");
		// var strCurrency = nlapiGetFieldValue("currency");
		// var strTransactionType = nlapiGetFieldValue("ntype");
		// var strTotal = nlapiGetFieldValue("total");
        // var recId = nlapiGetRecordId();
	    // var recType = nlapiGetRecordType().toLowerCase();
		
		nlapiLogExecution('DEBUG', method, "strSubsidiary: "+ strSubsidiary + ' strCurrency: ' + strCurrency + ' strTransactionType: ' + strTransactionType);

		var resulConfig = KS_AWT_userEvent.fnGetConfiguration(strSubsidiary,strCurrency,strTransactionType);
		// nlapiLogExecution('DEBUG', method, "resulConfig: "+ JSON.stringify(resulConfig));
		var fields = KS_AWT_userEvent.fnGetFields(resulConfig);
		// nlapiLogExecution('DEBUG', method, "fields: "+ JSON.stringify(fields));
		if(fields)
		{
			var strTypeLanguage = fields.custrecord_ks_atw_language;
			var strTypeATW = fields.custrecord_ks_atw_type;
			var strTypePhrase = fields.custrecord_ks_atw_show_type;
			var strCurrencyPlural = fields.custrecord_ks_display_currency_plural;
			var strCurrencySingular = fields.custrecord_ks_atw_display_currency_singu; 
			var strCentPlural = fields.custrecord_ks_atw_display_cent_plural;
			var strCentSingular = fields.custrecord_ks_atw_display_cent_singular;
			var strOrderPhrase = fields.custrecord_ks_atw_order_phrase;
            var strAmountField = fields.custrecord_ks_atw_amount;
            if(!strAmountField){
                strAmountField = 'custbody_ks_amount_to_words';
            }
            // nlapiLogExecution('DEBUG', method, "strAmountField: "+ strAmountField + ' recType: ' + recType + ' recId: ' + recId);
			
			// nlapiLogExecution('DEBUG', method,'strOrderPhrase: '+strOrderPhrase+ '| strTypeLanguage: '+strTypeLanguage+' | strTypeATW: '+strTypeATW+' | strTypePhrase'+strTypePhrase+' |strCurrencyPlural: '+strCurrencyPlural+' | strCurrencySingular: '+strCurrencySingular+' | strCentPlural: '+strCentPlural+' | strCentSingular: '+strCentSingular);
			
			var jsonCustomLanguage = nlapiLookupField("customrecord_ks_languaje_for_atw", strTypeLanguage, ["name","custrecord_ks_json_languaje","custrecord_ks_connector_of_cents"], null);
			// nlapiLogExecution('DEBUG', method, "jsonCustomLanguage: "+ JSON.stringify(jsonCustomLanguage));
			strTypeLanguage = jsonCustomLanguage.name;
			var strConector = jsonCustomLanguage.custrecord_ks_connector_of_cents;
			// nlapiLogExecution('DEBUG', method, "strConector: "+ strConector);

			numberToWords.i18n[jsonCustomLanguage.name] = JSON.parse(jsonCustomLanguage.custrecord_ks_json_languaje);
			
			// nlapiLogExecution('DEBUG', method, "numberToWords.i18n[jsonCustomLanguage.name]: "+ numberToWords.i18n[jsonCustomLanguage.name]);

			var strResult = KS_AWT_userEvent.fnATW(strTotal,strTypeLanguage,strTypeATW,strTypePhrase,strCurrencyPlural,strCurrencySingular,strCentPlural,strCentSingular, strConector, strOrderPhrase);
			// nlapiLogExecution('DEBUG', method, "strResult: "+ strResult);

            nlapiSubmitField(recType,recId,strAmountField,strResult)
			//nlapiSetFieldValue("custbody_ks_amount_to_words", strResult);
			// nlapiLogExecution('DEBUG', method, "valor en letras: "+strResult);
		} 
		else
		{
			nlapiLogExecution('DEBUG', method, "No vienen Campos para la configuracion");
		}
		
	}catch(e){
		nlapiLogExecution('ERROR', method, e);
	}	
}
KS_AWT_userEvent.fnGetConfiguration = function(strSubsidiary,strCurrency,strTransactionType)
{
	var method= "KS_AWT_userEvent.fnGetConfiguration";
	try {
		var filters = [];
		filters.push(new nlobjSearchFilter("custrecord_ks_atw_subsidiaria", null, "anyof", strSubsidiary));
		filters.push(new nlobjSearchFilter("custrecord_ks_atw_currency", null, "anyof", strCurrency));
		filters.push(new nlobjSearchFilter("isinactive", null, "is", "F"));
		filters.push(new nlobjSearchFilter("custrecord_ks_atw_transaction_type", null, "anyof", strTransactionType));		
		return nlapiSearchRecord("customrecord_ks_amount_to_words_config", null, filters, null);
	} catch (e) {
		nlapiLogExecution('ERROR', method, e);
	}
}
KS_AWT_userEvent.fnGetFields = function(resulConfig)
{
	var method = "KS_AWT_userEvent.fnGetFields";
	var result = null;
	try {
		if(resulConfig)
		{
			var config = {};
			resulConfig.forEach(function(element)
			{
				var nlapiConfig = nlapiLoadRecord("customrecord_ks_amount_to_words_config", element.getId());
				
				var fields = nlapiConfig.getAllFields();
				fields.forEach(function(element)
				{
					if(element.indexOf("custrecord_ks") != -1)
					{
						config[element] = nlapiConfig.getFieldValue(element);
						if(element.indexOf("custrecord_ks_atw_transaction_type") != -1)
							config[element] = nlapiConfig.getFieldValues(element);
					}
				});
			});
			
			result = config;
		}
		else
		{
			nlapiLogExecution('DEBUG', method, "Subsidiary: "+subsidiary+" con currency :"+strCurrency+" sin configuracion para la transaccion.");
		}
	} catch (e) {
		nlapiLogExecution('ERROR', method, e);
	}
	
	return result;
}
KS_AWT_userEvent.fnATW = function(strTotal,strTypeLanguage,strTypeATW,strTypePhrase,strCurrencyPlural,strCurrencySingular,strCentPlural,strCentSingular, strConector, strOrderPhrase) 
{
	var method = "KS_AWT_userEvent.fnATW";
	if(strConector == null)
	{
		strConector = "";
	}
	var strResult = null;
	try 
	{
		if(strTotal.length >= 0)
		{
			if (strTotal.indexOf(",") >= 0 || strTotal.indexOf(".") >= 0) 
			{
				if(strTotal.indexOf(",") >= 0)
					strTotal = strTotal.split(",");
				else if (strTotal.indexOf(".") >= 0)
					strTotal = strTotal.split(".");

				numPartFirts = KS_AWT_userEvent.fnGetWords(strTotal[0], strTypeLanguage);
				numPartSecond = KS_AWT_userEvent.fnGetWords(strTotal[1], strTypeLanguage);

				if(strTypeATW == "1")
				{
					strCentSingular = "";
					strCentPlural = "";
			
					numPartSecond = strTotal[1]+"/100";
					/*if(parseInt(strTotal[1]) == 0)
					{
						numPartSecond = "";
						strConector = "";
					}*/
				}

				if(strOrderPhrase == 1)
				{
					strCentSingular = strCurrencyPlural;
					strCurrencySingular = '';
					strCentPlural = strCurrencyPlural;
					strCurrencyPlural = '';
				}
				
				if(strTotal[0] == "1" & strTotal[1] == "1")
				{
					strResult = numPartFirts+" "+strCurrencySingular+" "+strConector+" "+numPartSecond+" "+strCentSingular;
				}
				else if(strTotal[0] == "1")
				{
					strResult = numPartFirts+" "+strCurrencySingular+" "+strConector+" "+numPartSecond+" "+strCentPlural;	
				}
				else if(strTotal[1] == "1")
				{
					strResult = numPartFirts+" "+strCurrencyPlural+" "+strConector+" "+numPartSecond+" "+strCentSingular;	
				}
				else
				{
					strResult = numPartFirts+" "+strCurrencyPlural+" "+strConector+" "+numPartSecond+" "+strCentPlural;		
				}
			}
			else 
			{ 
				numPartFirts = fnGetWords(strTotal, strTypeLanguage);
				
				if(strTotal == "1")
				{
					strResult = numPartFirts+" "+strCurrencySingular;
				}
				else 
				{
					strResult = numPartFirts+" "+strCurrencyPlural;
				}
			}	
			
			switch(strTypePhrase)
			{
				case "1":
					strResult = KS_AWT_userEvent.fnUpperCase(strResult);
					break;
				case "2":
					strResult = KS_AWT_userEvent.fnFirstCapitalLetter(strResult);
					break;
				case "3":
					strResult = KS_AWT_userEvent.fnFirstCapitalLetterInSentence(strResult);
					break;
			}			
		}
	}
	catch (e) 
	{
		nlapiLogExecution('ERROR', method, e);
	}
	
	return strResult;
}
KS_AWT_userEvent.fnFirstCapitalLetter = function (phrase) 
{
	var result = null;
	var method = "KS_AWT_userEvent.fnFirstCapitalLetter";
	try {
		result = phrase.charAt(0).toUpperCase() + phrase.slice(1);
	} catch (e) {
		nlapiLogExecution('ERROR', method, e);
	}
	return result;
}
KS_AWT_userEvent.fnUpperCase = function (phrase) 
{
	var result = null;
	var method = "KS_AWT_userEvent.fnUpperCase";
	try {
		result = phrase.toUpperCase();
	} catch (e) {
		nlapiLogExecution('ERROR', method, e);
	}
	return result;
}
KS_AWT_userEvent.fnFirstCapitalLetterInSentence = function (phrase) 
{
	
	var result = ""; 
	var method = "KS_AWT_userEvent.fnFirstCapitalLetterInSentence ";
	try 
	{
		phrase = phrase.split(" ");
		phrase.forEach(
			function(element)
			{
				result += KS_AWT_userEvent.fnFirstCapitalLetter(element)+" ";
			});
	} catch (e) {
		nlapiLogExecution('ERROR', method, e);
	}
	return result;
}
KS_AWT_userEvent.fnGetWords = function(strNum, strLanguage)
{
	var method = "KS_AWT_userEvent.fnGetWords";
	var result = null;
	try {
		result = numberToWords.convert(strNum, {lang: strLanguage});
	} catch (e) {
		nlapiLogExecution('ERROR', method, e);
	}
	return result;
}