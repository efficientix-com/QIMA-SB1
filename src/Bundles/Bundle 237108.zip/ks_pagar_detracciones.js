/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       25 Aug 2017     JuanKIS
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function ks_pe_pagarDetracciones(type) {
	var method = 'ut001_pagarDetracciones';
	try{
		var context = nlapiGetContext();
		
		var search_results = nlapiSearchRecord(null,'customsearch_ks_pe_detracc_por_pagar' , null, null);

		nlapiLogExecution('DEBUG', 'search_results',JSON.stringify(search_results));

		var account = context.getSetting('SCRIPT', 'custscript_ks_acc_detracciones'); //Cuenta de Banco
		var monedaDetracciones = context.getSetting('SCRIPT', 'custscript_ks_pe_monedadetra');
		var cuentacxpdetracion = context.getSetting('SCRIPT', 'custscript_ks_pe_cxcdetracciones'); //Cuenta por pagar
		var mediodepago = context.getSetting('SCRIPT', 'custscript_ks_pe_medio_pago'); //Medio de Pago
        var billform = context.getSetting('SCRIPT', 'custscript_ks_pe_billform');
		
		if(search_results){
          nlapiLogExecution('DEBUG', method, search_results.length);
			for (var int = 0; int < search_results.length; int++) {
              try{
				var record = search_results[int];
				var columns = record.getAllColumns();
				var bill_payment = nlapiTransformRecord('vendorbill', record.getValue(columns[6]), 'vendorpayment', {recordmode: 'dynamic'});
				var vendor = nlapiLookupField('vendorbill', record.getValue(columns[6]), 'entity');
				var billSubsidiary = nlapiLookupField('vendorbill', record.getValue(columns[6]), 'subsidiary');
				var amountJournal = getRelatedJournalAmount(record.getValue(columns[6]));
//				var account = nlapiLookupField('vendor', vendor, 'payablesaccount');
				
				bill_payment.setFieldValue('entity', vendor);
                //bill_payment.setFieldValue('subsidiary',3);
				bill_payment.setFieldValue('subsidiary',billSubsidiary);
                bill_payment.setFieldValue('currency',monedaDetracciones);
                bill_payment.setFieldValue('account', account);
				bill_payment.setFieldValue('apacct',cuentacxpdetracion);
				bill_payment.setFieldValue('custbody_ks_pe_medio_de_pago',mediodepago);
				
				nlapiLogExecution('DEBUG', 'pagarDetracciones valor',record.getValue(columns[6])+' Pagar Con:: '+account);
				

				var lines =bill_payment.getLineItemCount('apply');
				nlapiLogExecution('DEBUG', 'pagarDetracciones', lines+':'+vendor);
				var related_journal = getRelatedJournal(record.getValue(columns[6]));
				for (var lines_iterator = 1; lines_iterator <= lines; lines_iterator++) {
					bill_payment.selectLineItem('apply', lines_iterator)
					var current_id=bill_payment.getCurrentLineItemValue('apply','internalid');
					nlapiLogExecution('DEBUG', 'pagarDetracciones', current_id+'|'+related_journal);
					if(current_id==related_journal){
						nlapiLogExecution('DEBUG', 'pagarDetracciones', 'Aplicado');
						nlapiLogExecution('DEBUG', 'pagarDetracciones Pago', amountJournal);
						bill_payment.setCurrentLineItemValue('apply','apply', 'T');
						bill_payment.setCurrentLineItemValue('apply','amount',parseFloat(amountJournal));
						bill_payment.commitLineItem('apply')
					}
				}
				nlapiLogExecution('DEBUG', 'pagarDetracciones account','>>'+ bill_payment.getFieldValue('account'));
				var idpaym =nlapiSubmitRecord(bill_payment);
				nlapiLogExecution('DEBUG', 'pagarDetracciones','Pago::'+idpaym );
                /*var vb = nlapiLoadRecord('vendorbill', record.getValue(columns[6]),{customform:billform});
                vb.setFieldValue('custbody_ks_pe_detraccion_pagada','T')
                nlapiSubmitRecord(vb);*/
                nlapiSubmitField('vendorbill', record.getValue(columns[6]),'custbodyks_pe_detraccion_pagada','T')
              }catch(e){
				nlapiLogExecution('ERROR', method, e);
				}
			}
		}
	}catch(e){
		nlapiLogExecution('ERROR', method, e);
	}
}
function getRelatedJournalAmount(idfact){
	var amountJournal=0;
	try{
		var filters = new Array();
		filters.push(new nlobjSearchFilter('custbody_ks_pe_factura_vinculada', null, 'is',idfact));
		var search_results = nlapiSearchRecord('journalentry', 'customsearch_ks_pe_journal_detracciones', filters, null);
		if(search_results){
			for (var search_iterator = 0; search_iterator < search_results.length; search_iterator++) {
				var columns = search_results[search_iterator].getAllColumns();
				amountJournal= search_results[search_iterator].getValue(columns[2]);
			}
		}
	}catch(e){
		nlapiLogExecution('ERROR', 'getRelatedJournal', e);
	}
	return amountJournal;
}
function getRelatedJournal(idfact){
	var id_journal = null;
	try{
		var filters = new Array();
		filters.push(new nlobjSearchFilter('custbody_ks_pe_factura_vinculada', null, 'is',idfact));
		var search_results = nlapiSearchRecord('journalentry', 'customsearch_ks_pe_journal_detracciones', filters, null);
		if(search_results){
			for (var search_iterator = 0; search_iterator < search_results.length; search_iterator++) {
				var columns = search_results[search_iterator].getAllColumns();
				id_journal= search_results[search_iterator].getValue(columns[0]);
			}
		}
	}catch(e){
		nlapiLogExecution('ERROR', 'getRelatedJournal', e);
	}
	return id_journal;
}