/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       26 Dec 2016     JuanKIS
 *
 */
function ks_detraccion(request, response) {
	var form = nlapiCreateForm('Archivo de Detraccion', false);
	var subsidiary = form.addField('custpage_subsidiary', 'select', 'Subsidiaria: ', 'subsidiary');
	subsidiary.setMandatory(true);
	var lote = form.addField('custpage_vendor', 'text', 'Lote: ', 'vendor');
	lote.setMandatory(true);
	var account_filter = form.addField('custpage_account', 'select', 'Cuenta de Bancos ', 'account');
	account_filter.setMandatory(true);
	var context = nlapiGetContext();
	var FolderID = context.getSetting('SCRIPT', 'custscript_ks_pe_folder_id');
	form.addSubmitButton('Generar');
	form.addTab('custpage_data', 'Archivo de Detraccion');
	var myInlineHtml = form.addField('custpage_btn', 'inlinehtml', 'Name', null, 'custpage_data');
	var html = '';
	var factsPorPagar = new Array();
	var amountsAPagar = new Array();
	try {
		if (request.getMethod() == 'POST') {
			var result = '';
			//Busqueda: UT001 Modelo Archivo de Deuda
			var filters = new Array();
			var lote = request.getParameter('custpage_vendor');
			var account = request.getParameter('custpage_account');
			var subsidiary = request.getParameter('custpage_subsidiary');
			var total_archivo = 0;
			var filters = null;
			if (subsidiary) {
				var filters = new Array();
				filters[0] = new nlobjSearchFilter('internalid', "subsidiary", 'is', subsidiary);
			}

			var search_results = nlapiSearchRecord(null, 'customsearch_ks_pe_detracc_por_pagar', filters, null)
			
			if (search_results) {
				var idFactDetracc = [];
				for (var int = 0; int < search_results.length; int++) { var record = search_results[int]; var columns = record.getAllColumns(); idFactDetracc.push(record.getValue(columns[6])) }
				nlapiLogExecution('DEBUG', 'ks_detraccion', 'idFactDetracc: ' + idFactDetracc.length);
				var JRTotales = getRelatedJournalAmount(null, idFactDetracc);

				var record2 = search_results[0];
				var columns2 = record2.getAllColumns();
				var _ruc = record2.getValue(columns2[20]);
				var _nombre = record2.getValue(columns2[19]);
				nlapiLogExecution('debug','generararchivoAnder', JSON.stringify({
					_ruc:_ruc,
					_nombre:_nombre
				}))
				result += createHeader(search_results, lote, _ruc, _nombre) + '\r\n';
				for (var int = 0; int < search_results.length; int++) {
					nlapiLogExecution('AUDIT', 'HTML', 'HTML: ' + html);
					var record = search_results[int];
					var columns = record.getAllColumns();
					var temp_line = '';
					temp_line += '6';//Tipo DOC SUNAT
                    temp_line += record.getValue(columns[14]).replace('- None -', '0');//RUC Proveedor
					temp_line += zeroFiller('', 35, ' ');//Razon Social
					temp_line += zeroFiller('', 9, '0')//No Proforma
					temp_line += zeroFillerRight((record.getValue(columns[2]).trim()).replace('- None -', ''), 3, '0');//Codigo Servicio
					if(record.getValue(columns[3])=='- None -' || record.getValue(columns[3])==''){
						temp_line += zeroFiller(record.getValue(columns[3]).replace('- None -', ''), 11, ' ');//#Cuenta
					}else{
						temp_line += zeroFiller(record.getValue(columns[3]).replace('- None -', ''), 11, '0');//#Cuenta
					}
					if (record.getValue(columns[3]).replace('- None -', '') == '') {
						// nlapiLogExecution('AUDIT', 'Empty', 'True');
						html += '<p> El proveedor ' + record.getText(columns[7]) + ' no tiene la cuenta de detracciones.<a href="/app/common/entity/vendor.nl?id=' + record.getValue(columns[17]) + '&e=T"> Incluir</a> </p>\r\n'
						//						continue;
					}
					// var amt = getRelatedJournalAmount(record.getValue(columns[6]));
                    var idFacturaINV = record.getValue(columns[6]);
                    // var amt = JRTotales.filter(function (result) {return result.id == idFacturaINV });
                    var amt = "";
                    for (var index = 0; index < JRTotales.length; index++) {
                        // nlapiLogExecution('AUDIT', 'JRTotales[index].id', JRTotales[index].id)
                        // nlapiLogExecution('AUDIT', 'idFacturaINV', idFacturaINV)
                        if (JRTotales[index].id == idFacturaINV) {
                            amt = JRTotales[index].total;
                            nlapiLogExecution('AUDIT', 'amt', amt)
                        }

                    }
                    // var amt = "TESTING";
                    temp_line += zeroFiller(amt.replace('\.', ''), 15, '0');//#Importe
                    // temp_line+=zeroFillerRight(String(amt).replace('- None -',''),15,'0');//#Importe
                    total_archivo += parseInt(Number(amt));
                    temp_line += '01';//Tipo Comprobante
                    // temp_line += record.getValue(columns[5]);//Periodo
                    // temp_line += transformAccountingPeriod(record.getValue(columns[18]),record.getValue(columns[5]));//Periodo
                    temp_line += record.getValue(columns[18]);//Periodo
                    temp_line += '01';//Tipo Comprobante
                    var seriecxc = String(record.getValue(columns[16])).replace('- None -', '')
                    temp_line += zeroFiller(seriecxc, 4, '0');
                    temp_line += zeroFiller(String(record.getValue(columns[15])).replace('- None -', ''), 8, '0');
                    // nlapiLogExecution('AUDIT', 'Values NumCom', String(record.getValue(columns[16])).replace('- None -','').length)
                    if (int != search_results.length - 1) {
                        result += temp_line + '\r\n';
                    } else {
                        result += temp_line;
                    }
                    factsPorPagar.push(record.getValue(columns[6]));
                    amountsAPagar.push(record.getValue(columns[12]));
                }
			}else{

			}
			var total_string = parseFloat(total_archivo).toFixed(2).toString();
			result = String(result).replace('xxTotalxx', zeroFiller(total_string.substring(0, total_string.indexOf('.')) + '00', 15, '0'));
			
			var date =  new Date();
			var año = String(date.getFullYear())
			var file = nlapiCreateFile('D' + _ruc + año+zeroFiller(lote, 2, '0') + '.txt', 'PLAINTEXT', result);
			//var file = nlapiCreateFile('D' + _ruc + lote + '.txt', 'PLAINTEXT', result);

			file.setFolder(FolderID);
			var id = nlapiSubmitFile(file);
			var fileex = nlapiLoadFile(id);
			var url = fileex.getURL();
			html + '<div style="color:#0000FF">'
			html += '<a href="' + url + '" download>Archivo Generado</a></div>'
			try{
				var params = { custscript_ks_acc_detracciones: account }
				nlapiScheduleScript('customscript_ks_pe_pagar_detracciones', 'customdeploy_ks_pe_pagar_detracciones', params)
			}catch(e){
				nlapiLogExecution('DEBUG', 'ut001_archivoCobranza', 'Error: ' + e)
			}
			
		}
		myInlineHtml.setDefaultValue(html);
		response.writePage(form);

		//		pagarDetracciones(factsPorPagar,amountsAPagar,account);
	} catch (e) {
		nlapiLogExecution('ERROR', 'ut001_archivoCobranza', 'Error: ' + e)
	}


}
function pagarDetracciones(ids, amounts, account) {
	try {
		nlapiLogExecution('DEBUG', 'pagarDetracciones', 'Init: Account: ' + account);
		for (var ids_iterator = 0; ids_iterator < ids.length; ids_iterator++) {
			var bill_payment = nlapiTransformRecord('vendorbill', ids[ids_iterator], 'vendorpayment', { recordmode: 'dynamic' });
			var vendor = nlapiLookupField('vendorbill', ids[ids_iterator], 'entity');
			var amountJournal = getRelatedJournalAmount(ids[ids_iterator]);
			//			var account = nlapiLookupField('vendor', vendor, 'payablesaccount');
			bill_payment.setFieldValue('apacct', 6544);

			bill_payment.setFieldValue('entity', vendor);
			bill_payment.setFieldValue('account', account);
			var lines = bill_payment.getLineItemCount('apply');
			nlapiLogExecution('DEBUG', 'pagarDetracciones', lines + ':' + vendor);
			var related_journal = getRelatedJournal(ids[ids_iterator]);
			for (var lines_iterator = 1; lines_iterator <= lines; lines_iterator++) {
				bill_payment.selectLineItem('apply', lines_iterator)
				var current_id = bill_payment.getCurrentLineItemValue('apply', 'internalid');
				nlapiLogExecution('DEBUG', 'pagarDetracciones', current_id + '|' + related_journal);
				if (current_id == related_journal) {
					nlapiLogExecution('DEBUG', 'pagarDetracciones', 'Aplicado');
					bill_payment.setCurrentLineItemValue('apply', 'apply', 'T');
					bill_payment.setCurrentLineItemValue('apply', 'amount', parseFloat(amountJournal));
					bill_payment.commitLineItem('apply')
				}
			}
			nlapiLogExecution('DEBUG', 'pagarDetracciones', '>>' + bill_payment.getFieldValue('account'));
			nlapiSubmitRecord(bill_payment);
		}
	} catch (e) {
		nlapiLogExecution('ERROR', 'pagarDetracciones', 'Error: ' + e);
	}
}
function getRelatedJournal(idfact) {
	var id_journal = null;
	try {
		var filters = new Array();
		filters.push(new nlobjSearchFilter('custbody_ks_pe_factura_vinculada', null, 'is', idfact));
		var search_results = nlapiSearchRecord('journalentry', 'customsearch_ks_pe_journal_detracciones', filters, null);
		if (search_results) {
			for (var search_iterator = 0; search_iterator < search_results.length; search_iterator++) {
				var columns = search_results[search_iterator].getAllColumns();
				id_journal = search_results[search_iterator].getValue(columns[0]);
			}
		}
	} catch (e) {
		nlapiLogExecution('ERROR', 'getRelatedJournal', e);
	}
	return id_journal;
}
function getRelatedJournalAmount(idfact, arrayFacts) {
	var amountJournal = '0';
    var array = [];
    try {
        // nlapiLogExecution('DEBUG', 'getRelatedJournalAmount', "1");
        var filters = new Array();
        if (idfact) {
            var col = new Array();
            filters.push(new nlobjSearchFilter('custbody_ks_pe_factura_vinculada', null, 'is', idfact));
        } else if (arrayFacts.length > 0) {
            filters.push(new nlobjSearchFilter('custbody_ks_pe_factura_vinculada', null, 'anyof', arrayFacts));
            var col = new Array();
            // col[0] = new nlobjSearchColumn('tranid', null, 'group');
        }
        var search_results = nlapiSearchRecord('journalentry', 'customsearch_ks_pe_journal_detracciones', filters, col);
        //nlapiLogExecution('DEBUG', 'getRelatedJournal', "length " + JSON.stringify(search_results));
        if (search_results) {
            if (search_results.length > 0) {
                for (var search_iterator = 0; search_iterator < search_results.length; search_iterator++) {
                    var columns = search_results[search_iterator].getAllColumns();
                    amountJournal = search_results[search_iterator].getValue(columns[2]);
                    array.push({ "id": search_results[search_iterator].getValue(columns[3]), "total": search_results[search_iterator].getValue(columns[2]) })
                }
            }
        }
    } catch (e) {
        nlapiLogExecution('ERROR', 'getRelatedJournalAmount', e);
    }
    if (array.length > 0) {
        return array;
    }
    return amountJournal;
}
function zeroFiller(value, size, character) {
	if (value.length < size) {
		var dif_size = size - value.length;
		for (var int = 0; int < dif_size; int++) {
			value = value + character;
		}

	} else if (value.length > size) {
		return value.substring(value.length - size, value.length);
	}
	return value;
}
function zeroFillerRight(value, size, character) {
	if (value.length < size) {
		var dif_size = size - value.length;
		for (var int = 0; int < dif_size; int++) {
			value = value + character;
		}


	} else if (value.length > size) {
		return value.substring(value.length - size, value.length);
	}
	return value;
}
function zeroFillerNew(value, size, character) {
	if (value.length < size) {
		var dif_size = size - value.length;
		for (var int = 0; int < dif_size; int++) {
			value = value + character;
		}


	} else if (value.length > size) {
		return value.substring(0, size);
	}
	return value;
}
function createHeader(search_results, lote, ruc, name) {
	var temp_line = '';
	try {
		temp_line += '*';
		temp_line += ruc;
		temp_line += zeroFillerRight(name, 35, ' ');
		var date = new Date();
        // var año = String(date.getFullYear()).substring(2,4)
        var año = String(date.getFullYear())
        temp_line += año + "" + zeroFiller(lote, 2, '0');
        // temp_line += zeroFiller(lote, 4, '0');
		temp_line += 'xxTotalxx';
		//		var total =getTotalDetracc().toString();	
		//		temp_line+=zeroFiller(total.substring(0,total.indexOf('.'))+'00',15,'0');//C9

	} catch (e) {
		nlapiLogExecution('ERROR', 'ut001_archivoCobranza', 'Error: ' + e)
	}
	return temp_line;
}
function zeroFiller(value, size, character) {
	if (value.length < size) {
		var dif_size = size - value.length;
		for (var int = 0; int < dif_size; int++) {
			value = character + value;
		}

	} else if (value.length > size) {
		return value.substring(value.length - size, value.length);
	}
	return value;
}
function getTotalDetracc() {
	var filters = new Array();
	var total = 0;
	var search_results = nlapiSearchRecord(null, 'customsearch_ks_pe_detracc_por_paga_2', null, null);
	if (search_results) {
		for (var int = 0; int < search_results.length; int++) {
			var record = search_results[int];
			var columns = record.getAllColumns();
			total = record.getValue(columns[0])
		}

	}
	nlapiLogExecution('AUDIT', 'getTotalDeuda', 'Total: ' + total)
	return total;
}