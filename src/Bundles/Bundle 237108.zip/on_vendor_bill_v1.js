/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       08 Dec 2016     John Hern�ndez
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
var context = nlapiGetContext();
var ks_memo = context.getSetting('SCRIPT', 'custscript_ks_pe_memodetraccion');
var ks_tipoasiento = context.getSetting('SCRIPT', 'custscript_ks_pe_clasificacioindetra');
var ksJournalAdjDet = context.getSetting('SCRIPT', 'custscript_ks_pe_clasificacioindetra_adj');
var currencyDet = context.getSetting('SCRIPT', 'custscript_ks_pe_monedadetraccion');
//nlapiLogExecution('DEBUG', 'generar journal', 'ks_tipoasiento: ' + ks_tipoasiento);
//Funcion para crear journal de detracciones
function createJournal(id, monedadetraccion) {
    try {
        nlapiLogExecution('DEBUG', 'generar journal', 'init');
        //var accountSetup = getAccountSetup();
        //Variable para guardar el id interno del journal de detracciones
        var idJournal = 0;
        //Objeto que carga la informaci�n del vendor bill creado
        var VendorBill = nlapiLoadRecord('vendorbill', id);
        //Conteo de lineas de items en el vendor bill
        var count = VendorBill.getLineItemCount('item');

        //Consulta los numeros de cuenta en el account setup para verificar spbre que lineas se debe crear journal de detracciones
        var accountOrigen = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_origen');
        var accountDestino = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_destino');
        var accountOrigenDolares = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_origen_dol');

        nlapiLogExecution('DEBUG', 'generar journal', 'init accountDestino ' + accountDestino);
        nlapiLogExecution('DEBUG', 'generar journal', 'init accountOrigen ' + accountOrigen);
        nlapiLogExecution('DEBUG', 'generar journal', 'init accountOrigenDolares ' + accountOrigenDolares);
        nlapiLogExecution('DEBUG', 'generar journal', 'init num items' + count);
        //Variable para almacenar el monto del journal
        var amount = 0;
        //Ciclo para recorrer las distintas lineas de items
        for (var i = 1; i <= count; i++) {
            //Objeto que almacena el item que esta siendo verificado en el ciclo
            var itemLine = VendorBill.getLineItemValue('item', 'item', i);
            nlapiLogExecution('DEBUG', 'generar journal', 'init item id ' + itemLine);
            //Variable que almacena el tipo de articulo al que pertenece el item
            var articletype = VendorBill.getLineItemValue('item', 'itemtype', i);
            //var articletype=nlapiLookupField('item', itemLine, 'type');
            nlapiLogExecution('DEBUG', 'generar journal', 'init line type ' + articletype);
            //Valida si el item es un item de descuento
            if (articletype == 'Discount') {
                //Objeto que almacena el articulo que se incluyo en la linea
                var article = nlapiLoadRecord('discountitem', itemLine);
                //valor de la cuenta que tiene asignada el articulo
                var accountLine = article.getFieldValue('account');
                nlapiLogExecution('DEBUG', 'generar journal', 'init line discount ' + i);
                //var accountLine=nlapiLookupField('discountitem', itemLine, 'accountingbook');
                nlapiLogExecution('DEBUG', 'generar journal', 'init item account ' + accountLine);
                //Valida si la cuenta del articulo es igual a la cuenta configurada en el account setup
                var exchangerate = nlapiLookupField('vendorbill', id, 'exchangerate');
                if (parseInt(accountLine) == parseInt(accountDestino) || parseInt(accountLine) == parseInt(accountOrigen) || parseInt(accountLine) == parseInt(accountOrigenDolares)) {
                    amount = parseInt(Math.round(VendorBill.getLineItemValue('item', 'amount', i) * exchangerate));
                    nlapiLogExecution('DEBUG', 'Editar journal', 'item amount:: ' + amount + " exchangerate:: " + exchangerate);
                }
                //Objeto que almacenara el journal a crear
                var journal = nlapiCreateRecord('journalentry');
                //				var moneda = nlapiLookupField('invoice', id, 'currency',true);
                //Valor que almacena el tipo de moneda del vendor bill
                var monedaID = nlapiLookupField('vendorbill', id, 'currency');

                nlapiLogExecution('DEBUG', 'generar journal', 'init moneda ' + monedaID);
                //Valor que almacena la location del vendor bill
                var location = nlapiLookupField('vendorbill', id, 'location');

                //var location = nlapiLookupField('vendorbill', id, 'location');
                var location = VendorBill.getLineItemValue('item', 'location', i);
                var department = VendorBill.getLineItemValue('item', 'department', i);
                nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 2 ' + department);

                //var clase = nlapiLookupField('vendorbill', id, 'class');
                //Valor que almacenala clase del vendor bill
                var clase = VendorBill.getLineItemValue('item', 'class', i);
                //Valor que almacena la subsidiaria del vendor bill
                var subsidiary = nlapiLookupField('vendorbill', id, 'subsidiary');
                nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 2');
                //nlapiSubmitField('invoice', id, 'custbody_ut001_provisionada', 'T');
                nlapiLogExecution('DEBUG', 'FacturaActualizada_', id);
                //Valor que almacena el proveedor del vendor bill
                var vendor = nlapiLookupField('vendorbill', id, 'entity');
                //Asigna los valores consultados al journal
                journal.setFieldValue('currency', monedadetraccion);
                journal.setFieldValue('approvalstatus', 2);

                journal.setFieldValue('custbody_ks_pe_factura_vinculada', id);
                journal.setFieldValue('custbody_ks_pe_tipo_journal', ks_tipoasiento);
                journal.setFieldValue('subsidiary', subsidiary);
                if (department) {
                    journal.setFieldValue('department', parseInt(department));
                }

                nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 3');
                journal.selectNewLineItem('line');
                journal.setCurrentLineItemValue('line', 'memo', ks_memo);
                journal.setCurrentLineItemValue('line', 'account', parseInt(accountDestino));
                journal.setCurrentLineItemValue('line', 'debit', amount);
                journal.setCurrentLineItemValue('line', 'class', clase);
                journal.setCurrentLineItemValue('line', 'location', location);
                if (department) {
                    journal.setCurrentLineItemValue('line', 'department', parseInt(department));
                }
                journal.setCurrentLineItemValue('line', 'entity', vendor);
                journal.commitLineItem('line');
                journal.selectNewLineItem('line');
                //Asigna el numerod e cuenta a el valor de la linea del journal dependiendo de la moneda origen
                if (monedaID == monedadetraccion) {
                    journal.setCurrentLineItemValue('line', 'account', parseInt(accountOrigen));
                } else {
                    journal.setCurrentLineItemValue('line', 'account', parseInt(accountOrigenDolares));
                }
                journal.setCurrentLineItemValue('line', 'memo', ks_memo);

                journal.setCurrentLineItemValue('line', 'credit', amount);
                journal.setCurrentLineItemValue('line', 'class', clase);
                journal.setCurrentLineItemValue('line', 'location', location);
                journal.setCurrentLineItemValue('line', 'entity', vendor);
                if (department) {
                    journal.setCurrentLineItemValue('line', 'department', parseInt(department));
                }
                //Crea el journal
                journal.commitLineItem('line');

                nlapiLogExecution('DEBUG', 'vendorBillJournal item', 'init 4 department ' + department);
                nlapiLogExecution('DEBUG', 'vendorBillJournal item', 'init 4 accountDestino ' + accountDestino);
                nlapiLogExecution('DEBUG', 'vendorBillJournal item', 'init 4 vendor ' + vendor);
                nlapiLogExecution('DEBUG', 'vendorBillJournal item', 'init 4 clase ' + clase);
                nlapiLogExecution('DEBUG', 'vendorBillJournal item', 'init 4 accountOrigen ' + accountOrigen);
                nlapiLogExecution('DEBUG', 'vendorBillJournal item', 'init 4 credit ' + amount);
                nlapiLogExecution('DEBUG', 'vendorBillJournal item', 'init 4 subsidiary ' + subsidiary);


                idJournal = nlapiSubmitRecord(journal, false, true);
                nlapiLogExecution('DEBUG', 'JournalCreated', idJournal);


            }


            //amount = nlapiLookupField('vendorbill', id, 'total');

        }
        //Cuenta las lineas de gastos
        var countExpense = VendorBill.getLineItemCount('expense');
        nlapiLogExecution('DEBUG', 'generar journal', 'init num expenses' + countExpense);
        //variable para almacenar el monto del journal
        var amount = 0;
        //Ciclo para recorrer las lineas de gastos 
        for (var i = 1; i <= countExpense; i++) {

            //Variable que almacena las lineas de gastos
            var accountLine = VendorBill.getLineItemValue('expense', 'account', i);
            nlapiLogExecution('DEBUG', 'generar journal', 'init line account' + accountLine);
            //nlapiLogExecution('DEBUG', 'generar journal', 'init acc setup 1' +accountSetup[21]);
            //nlapiLogExecution('DEBUG', 'generar journal', 'init acc setup 1' +accountSetup[22]);
            var exchangerate = nlapiLookupField('vendorbill', id, 'exchangerate');
            if (parseInt(accountLine) == parseInt(accountDestino) || parseInt(accountLine) == parseInt(accountOrigen) || parseInt(accountLine) == parseInt(accountOrigenDolares)) {
                amount = parseInt(Math.round(VendorBill.getLineItemValue('expense', 'amount', i)) * exchangerate);
                nlapiLogExecution('DEBUG', 'generar journal', 'init' + amount);

                //Objeto que almacenara el journal a crear
                var journal = nlapiCreateRecord('journalentry');
                //			var moneda = nlapiLookupField('invoice', id, 'currency',true);
                var monedaID = nlapiLookupField('vendorbill', id, 'currency');
                //var location = nlapiLookupField('vendorbill', id, 'location');
                var location = VendorBill.getLineItemValue('expense', 'location', i);
                var department = VendorBill.getLineItemValue('expense', 'department', i);
                nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 2 ' + department);
                //var clase = nlapiLookupField('vendorbill', id, 'class');
                var clase = VendorBill.getLineItemValue('expense', 'class', i);
                var vendor = nlapiLookupField('vendorbill', id, 'entity');
                var subsidiary = nlapiLookupField('vendorbill', id, 'subsidiary');

                nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 2');
                nlapiLogExecution('DEBUG', 'FacturaActualizada_', id);
                nlapiLogExecution('DEBUG', 'monedadetraccion ', monedadetraccion);
                var moneda = context.getSetting('SCRIPT', 'custscript_ks_pe_monedadetraccion');
                nlapiLogExecution('DEBUG', 'monedadetraccion ', moneda);

                journal.setFieldValue('subsidiary', subsidiary);
                journal.setFieldValue('currency', moneda);
                journal.setFieldValue('custbody_ks_pe_factura_vinculada', id);
                journal.setFieldValue('custbody_ks_pe_tipo_journal', ks_tipoasiento);
                journal.setFieldValue('department', parseInt(department));
                journal.setFieldValue('approvalstatus', 2);
                nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 3');
                journal.selectNewLineItem('line');
                journal.setCurrentLineItemValue('line', 'memo', ks_memo);
                journal.setCurrentLineItemValue('line', 'account', parseInt(accountDestino));
                journal.setCurrentLineItemValue('line', 'debit', amount);

                nlapiLogExecution('DEBUG', 'monto', amount);
                if (clase) {
                    journal.setCurrentLineItemValue('line', 'class', clase);
                }
                nlapiLogExecution('DEBUG', 'clase', clase);
                if (location) {
                    journal.setCurrentLineItemValue('line', 'location', location);
                }
                if (department) {
                    journal.setCurrentLineItemValue('line', 'department', parseInt(department));
                }

                nlapiLogExecution('DEBUG', 'ubicacion', location);
                journal.setCurrentLineItemValue('line', 'entity', vendor);
                journal.commitLineItem('line');
                journal.selectNewLineItem('line');
                journal.setCurrentLineItemValue('line', 'memo', ks_memo);
                if (monedaID == 1) {
                    journal.setCurrentLineItemValue('line', 'account', parseInt(accountOrigen));
                } else {
                    journal.setCurrentLineItemValue('line', 'account', parseInt(accountOrigenDolares));
                }
                journal.setCurrentLineItemValue('line', 'credit', amount);
                if (clase) {
                    journal.setCurrentLineItemValue('line', 'class', clase);
                }
                if (location) {
                    journal.setCurrentLineItemValue('line', 'location', location);
                }
                if (department) {
                    journal.setCurrentLineItemValue('line', 'department', parseInt(department));
                }
                journal.setCurrentLineItemValue('line', 'entity', vendor);
                journal.commitLineItem('line');

                nlapiLogExecution('DEBUG', 'vendorBillJournalexp', 'init 4 ' + department);
                idJournal = nlapiSubmitRecord(journal, false, true);
                nlapiLogExecution('DEBUG', 'JournalCreated', idJournal);

            }


        }


    } catch (e) {
        nlapiLogExecution('ERROR', 'Error Creando Journal det', e);
    }
    return idJournal;

}


function editJournal(id, monedadetraccion) {
    try {
        var idJournal;
        nlapiLogExecution('DEBUG', 'generar journal', 'init');
        //var accountSetup = getAccountSetup();
        var VendorBill = nlapiLoadRecord('vendorbill', id);
        var count = VendorBill.getLineItemCount('item');
        var accountOrigen = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_origen');
        var accountDestino = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_destino');
        var accountOrigenDolares = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_origen_dol');

        nlapiLogExecution('DEBUG', 'generar journal', 'init acc setup 1' + accountDestino);
        nlapiLogExecution('DEBUG', 'generar journal', 'init acc setup 1' + accountOrigen);
        nlapiLogExecution('DEBUG', 'generar journal', 'init acc setup 1' + accountOrigenDolares);
        nlapiLogExecution('DEBUG', 'generar journal', 'init num items' + count);

        var amount = 0;
        for (var i = 1; i <= count; i++) {
            var itemLine = VendorBill.getLineItemValue('item', 'item', i);
            nlapiLogExecution('DEBUG', 'generar journal', 'init item id ' + itemLine);
            var articletype = VendorBill.getLineItemValue('item', 'itemtype', i);
            //var articletype=nlapiLookupField('ite8m', itemLine, 'type');
            nlapiLogExecution('DEBUG', 'generar journal', 'init line type ' + articletype);
            if (articletype == 'Discount') {
                var article = nlapiLoadRecord('discountitem', itemLine);
                var accountLine = article.getFieldValue('account');
                nlapiLogExecution('DEBUG', 'generar journal', 'init line discount ' + i);
                //var accountLine=nlapiLookupField('discountitem', itemLine, 'accountingbook');
                nlapiLogExecution('DEBUG', 'generar journal', 'init item account ' + accountLine);
                var exchangerate = nlapiLookupField('vendorbill', id, 'exchangerate');
                if (parseInt(accountLine) == parseInt(accountDestino) || parseInt(accountLine) == parseInt(accountOrigen) || parseInt(accountLine) == parseInt(accountOrigenDolares)) {
                    amount = parseInt(Math.round(VendorBill.getLineItemValue('item', 'amount', i) * exchangerate));
                    nlapiLogExecution('DEBUG', 'Editar journal', 'item amount:: ' + amount + " exchangerate:: " + exchangerate);
                }

                var filters = new Array();
                filters[0] = new nlobjSearchFilter('custbody_ks_pe_factura_vinculada', null, 'anyof', [id]);
                filters[1] = new nlobjSearchFilter('custbody_ks_pe_tipo_journal', null, 'anyof', [ks_tipoasiento]);
                var columns = new Array();
                columns[0] = new nlobjSearchColumn('internalid');

                var journalResults = nlapiSearchRecord('journalentry', null, filters, columns);
                nlapiLogExecution('DEBUG', 'actualzar journal', 'journalResults ' + JSON.stringify(journalResults));

                if (!journalResults) {
                    idJournal = createJournal(id, monedadetraccion);
                } else {
                    for (j = 0; j < journalResults.length; j++) {
                        var journalId = journalResults[j].getValue(columns[0]);
                        nlapiLogExecution('DEBUG', 'Jpurnal a actualizar', journalId);
                        var journal = nlapiLoadRecord('journalentry', journalId);
                        //					var moneda = nlapiLookupField('invoice', id, 'currency',true);
                        var monedaID = nlapiLookupField('vendorbill', id, 'currency');
                        //var location = nlapiLookupField('vendorbill', id, 'location');
                        var location = VendorBill.getLineItemValue('item', 'location', i);
                        var department = VendorBill.getLineItemValue('item', 'department', i);
                        nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 2 ' + department);
                        //var clase = nlapiLookupField('vendorbill', id, 'class');
                        var clase = VendorBill.getLineItemValue('item', 'class', i);

                        var vendor = nlapiLookupField('vendorbill', id, 'entity');

                        nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 2');
                        //nlapiSubmitField('invoice', id, 'custbody_ut001_provisionada', 'T');
                        nlapiLogExecution('DEBUG', 'FacturaActualizada_', id);

                        //nlapiLogExecution('DEBUG', 'FacturaActualizada_', accountSetup);
                        //journal.setFieldValue('custbody_ut001_tipotra_je', '9');
                        //journal.setFieldValue('currency',monedadetraccion);
                        journal.setFieldValue('custbody_ks_pe_factura_vinculada', id);
                        journal.setFieldValue('custbody_ks_pe_tipo_journal', ks_tipoasiento);
                        journal.setFieldValue('approvalstatus', 2);
                        if (department) {
                            journal.setFieldValue('department', parseInt(department));
                        }
                        nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 3');
                        journal.selectLineItem('line', 1);
                        //journal.selectNewLineItem('line');
                        journal.setCurrentLineItemValue('line', 'memo', ks_memo);
                        journal.setCurrentLineItemValue('line', 'account', parseInt(accountDestino));
                        journal.setCurrentLineItemValue('line', 'debit', amount);
                        if (clase) {
                            journal.setCurrentLineItemValue('line', 'class', clase);
                        }
                        if (location) {
                            journal.setCurrentLineItemValue('line', 'location', location);
                        }
                        if (department) {
                            journal.setCurrentLineItemValue('line', 'department', parseInt(department));
                        }

                        journal.setCurrentLineItemValue('line', 'entity', vendor);
                        journal.commitLineItem('line');
                        journal.selectLineItem('line', 2);
                        journal.setCurrentLineItemValue('line', 'memo', ks_memo);
                        if (monedaID == 1) {
                            journal.setCurrentLineItemValue('line', 'account', parseInt(accountOrigen));
                        } else {
                            journal.setCurrentLineItemValue('line', 'account', parseInt(accountOrigenDolares));
                        }

                        journal.setCurrentLineItemValue('line', 'credit', amount);
                        if (clase) {
                            journal.setCurrentLineItemValue('line', 'class', clase);
                        }
                        if (location) {
                            journal.setCurrentLineItemValue('line', 'location', location)
                        }
                        if (department) {
                            journal.setCurrentLineItemValue('line', 'department', parseInt(department));
                        }

                        journal.setCurrentLineItemValue('line', 'entity', vendor);
                        journal.commitLineItem('line');


                        nlapiLogExecution('DEBUG', 'vendorBillJournal item', 'init 4 ' + department);
                        idJournal = nlapiSubmitRecord(journal, false, true);
                        nlapiLogExecution('DEBUG', 'JournalCreated', idJournal);
                        break;

                    }
                }




            }

            //amount = nlapiLookupField('vendorbill', id, 'total');

        }


        var countExpense = VendorBill.getLineItemCount('expense');
        nlapiLogExecution('DEBUG', 'generar journal', 'init num expenses' + countExpense);
        for (var i = 1; i <= countExpense; i++) {
            var accountLine = VendorBill.getLineItemValue('expense', 'account', i);
            nlapiLogExecution('DEBUG', 'generar journal', 'init line account' + accountLine);

            //nlapiLogExecution('DEBUG', 'generar journal', 'init acc setup 1' +accountSetup[21]);
            //nlapiLogExecution('DEBUG', 'generar journal', 'init acc setup 1' +accountSetup[22]);
            var exchangerate = nlapiLookupField('vendorbill', id, 'exchangerate');
            if (parseInt(accountLine) == parseInt(accountDestino) || parseInt(accountLine) == parseInt(accountOrigen) || parseInt(accountLine) == parseInt(accountOrigenDolares)) {
                amount = parseInt(Math.round(VendorBill.getLineItemValue('expense', 'amount', i)) * exchangerate)


                var filters = new Array();
                filters[0] = new nlobjSearchFilter('custbody_ks_pe_factura_vinculada', null, 'anyof', [id]);
                filters[1] = new nlobjSearchFilter('custbody_ks_pe_tipo_journal', null, 'anyof', [ks_tipoasiento]);
                var columns = new Array();
                columns[0] = new nlobjSearchColumn('internalid');

                var journalResults = nlapiSearchRecord('journalentry', null, filters, columns);
                //nlapiLogExecution('DEBUG', 'Jpurnal a actualizar', journalResults.length);
                if (!journalResults) {
                    nlapiLogExecution('DEBUG', 'generar journal', 'init create' + id);
                    idJournal = createJournal(id);
                } else {
                    for (j = 0; j <= journalResults.length; j++) {
                        var journalId = journalResults[j].getValue(columns[0]);
                        nlapiLogExecution('DEBUG', 'Jpurnal a actualizar', journalId);
                        var journal = nlapiLoadRecord('journalentry', journalId);
                        //					var moneda = nlapiLookupField('invoice', id, 'currency',true);
                        var monedaID = nlapiLookupField('vendorbill', id, 'currency');
                        //var location = nlapiLookupField('vendorbill', id, 'location');
                        var location = VendorBill.getLineItemValue('expense', 'location', i);
                        var department = VendorBill.getLineItemValue('expense', 'department', i);
                        nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 2 ' + department);
                        //var clase = nlapiLookupField('vendorbill', id, 'class');
                        var clase = VendorBill.getLineItemValue('expense', 'class', i);
                        var vendor = nlapiLookupField('vendorbill', id, 'entity');

                        nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 2');
                        //nlapiSubmitField('invoice', id, 'custbody_ut001_provisionada', 'T');
                        nlapiLogExecution('DEBUG', 'FacturaActualizada_', id);

                        //nlapiLogExecution('DEBUG', 'FacturaActualizada_', accountSetup);
                        //journal.setFieldValue('custbody_ut001_tipotra_je', '9');
                        journal.setFieldValue('currency', monedadetraccion);
                        journal.setFieldValue('custbody_ks_pe_factura_vinculada', id);
                        journal.setFieldValue('department', parseInt(department));
                        journal.setFieldValue('approvalstatus', 2);
                        journal.setFieldValue('custbody_ks_pe_tipo_journal', ks_tipoasiento);

                        nlapiLogExecution('DEBUG', 'vendorBillJournal', 'init 3');
                        journal.selectLineItem('line', 1);
                        //journal.selectNewLineItem('line');
                        journal.setCurrentLineItemValue('line', 'memo', ks_memo);
                        journal.setCurrentLineItemValue('line', 'account', parseInt(accountDestino));
                        journal.setCurrentLineItemValue('line', 'debit', amount);
                        journal.setCurrentLineItemValue('line', 'class', clase);
                        journal.setCurrentLineItemValue('line', 'location', location);
                        journal.setCurrentLineItemValue('line', 'department', parseInt(department));
                        journal.setCurrentLineItemValue('line', 'entity', vendor);
                        journal.commitLineItem('line');
                        journal.selectLineItem('line', 2);
                        //journal.selectNewLineItem('line');
                        journal.setCurrentLineItemValue('line', 'memo', ks_memo);
                        if (monedaID == monedadetraccion) {
                            journal.setCurrentLineItemValue('line', 'account', parseInt(accountOrigen));
                        } else {
                            journal.setCurrentLineItemValue('line', 'account', parseInt(accountOrigenDolares));
                        }
                        //journal.setCurrentLineItemValue('line', 'account', parseInt(accountOrigen));
                        journal.setCurrentLineItemValue('line', 'credit', amount);
                        journal.setCurrentLineItemValue('line', 'class', clase);
                        journal.setCurrentLineItemValue('line', 'location', location);
                        journal.setCurrentLineItemValue('line', 'entity', vendor);
                        journal.setCurrentLineItemValue('line', 'department', parseInt(department));

                        journal.commitLineItem('line');


                        nlapiLogExecution('DEBUG', 'vendorBillJournal exp ed', 'init 4 ' + department);
                        idJournal = nlapiSubmitRecord(journal, false, true);
                        nlapiLogExecution('DEBUG', 'JournalCreated', idJournal);
                        break;

                    }
                }

            }


        }

        //amount = nlapiLookupField('vendorbill', id, 'total');

    } catch (e) {
        nlapiLogExecution('ERROR', 'error editando journal det', e);
    }
    return idJournal;

}


function RoundTax(id) {
    try {
        var title = 'RoundTax';
        var VendorBill = nlapiLoadRecord('vendorbill', id);
        var exchangerate = VendorBill.getFieldValue('exchangerate');
        var count = VendorBill.getLineItemCount('item');
        var accountOrigenDolares = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_origen_dol');

        var accountOrigen = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_origen');
        var accountDestino = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_destino');
        nlapiLogExecution('DEBUG', title, 'accountOrigenDolares:: ' + accountOrigenDolares);

        nlapiLogExecution('DEBUG', title, 'accountDestino:: ' + accountDestino);
        nlapiLogExecution('DEBUG', title, 'accountOrigen:: ' + accountOrigen);
        nlapiLogExecution('DEBUG', title, '# num items:: ' + count);

        var JournalLines = []

        for (var i = 1; i <= count; i++) {
            var journalLine = {};
            var itemLine = VendorBill.getLineItemValue('item', 'item', i);
            nlapiLogExecution('DEBUG', title, 'init item id ' + itemLine);
            var articletype = VendorBill.getLineItemValue('item', 'itemtype', i);
            nlapiLogExecution('DEBUG', title, 'init line type ' + articletype);
            if (articletype == 'Discount') {
                var article = nlapiLoadRecord('discountitem', itemLine);
                var accountLine = article.getFieldValue('account');
                nlapiLogExecution('DEBUG', title, 'init line discount ' + i);
                nlapiLogExecution('DEBUG', title, 'init item account ' + accountLine);
                if (parseInt(accountLine) == parseInt(accountDestino) || parseInt(accountLine) == parseInt(accountOrigen) || parseInt(accountLine) == parseInt(accountOrigenDolares)) {
                    // var amount = parseInt( Math.round(VendorBill.getLineItemValue('item', 'amount', i)));
                    // nlapiLogExecution('DEBUG', 'Redondeo impuesto', 'init' +amount);
                    // VendorBill.setLineItemValue('item', 'amount', i, amount);
                    var lineAmount = parseFloat(VendorBill.getLineItemValue('item', 'amount', i));
                    nlapiLogExecution('DEBUG', title, 'item amount ' + lineAmount);
                    lineAmount = parseFloat(lineAmount) * parseFloat(exchangerate);
                    nlapiLogExecution('DEBUG', title, 'item amount converted' + lineAmount);
                    var amount = parseInt(Math.round(lineAmount * -1) * -1);
                    var originalAmount = parseFloat(amount)
                    nlapiLogExecution('DEBUG', title, 'item amount or' + originalAmount);
                    VendorBill.setLineItemValue('item', 'custcol_ks_det_original_amount', i, parseFloat(originalAmount));
                    amount = (parseFloat(amount) / parseFloat(exchangerate)).toFixed(2);
                    nlapiLogExecution('DEBUG', title, 'amount items:: ' + amount);
                    VendorBill.setLineItemValue('item', 'amount', i, amount);
                    VendorBill.setLineItemValue('item', 'rate', i, amount * 1);

                    journalLine.originalAmount = parseFloat(originalAmount);
                    journalLine.newAmountER = parseFloat(amount * exchangerate);
                    journalLine.amountDif = Math.abs(parseFloat(originalAmount)) - Math.abs(parseFloat(amount * exchangerate));
                    journalLine.account = parseInt(accountLine);
                    journalLine.locationId = parseInt(VendorBill.getLineItemValue('item', 'location', i));
                    journalLine.classId = parseInt(VendorBill.getLineItemValue('item', 'class', i));
                    journalLine.departmentId = parseInt(VendorBill.getLineItemValue('item', 'department', i));
                    if (parseFloat(journalLine.amountDif) != 0) {
                        JournalLines.push(journalLine);
                    }
                }
            }

        }

        var countExpense = VendorBill.getLineItemCount('expense');
        nlapiLogExecution('DEBUG', 'generar journal', '# num expenses::' + countExpense);
        var amount = 0;
        for (var i = 1; i <= countExpense; i++) {
            var journalLine = {};
            var accountLine = VendorBill.getLineItemValue('expense', 'account', i);
            nlapiLogExecution('DEBUG', title, 'init line account:: ' + accountLine);
            if (parseInt(accountLine) == parseInt(accountDestino) || parseInt(accountLine) == parseInt(accountOrigen) || parseInt(accountLine) == parseInt(accountOrigenDolares)) {
                // var amount =parseInt( Math.round(VendorBill.getLineItemValue('expense', 'amount', i)));
                // nlapiLogExecution('DEBUG', 'Redondeo impuesto', 'init' +amount);
                // VendorBill.setLineItemValue('expense', 'amount', i, amount);
                var lineAmount = parseFloat(VendorBill.getLineItemValue('expense', 'amount', i));
                lineAmount = parseFloat(lineAmount) * parseFloat(exchangerate);
                var amount = parseInt(Math.round(lineAmount));
                var originalAmount = parseFloat(amount)
                nlapiLogExecution('DEBUG', title, 'item amount or' + originalAmount);
                VendorBill.setLineItemValue('expense', 'custcol_ks_det_original_amount', i, parseFloat(originalAmount));
                amount = (parseFloat(amount) / parseFloat(exchangerate)).toFixed(2);
                nlapiLogExecution('DEBUG', title, 'amount expenses: ' + amount);
                VendorBill.setLineItemValue('expense', 'amount', i, amount);

                var lineWhAmount = parseFloat(VendorBill.getLineItemValue('expense', 'custcol_4601_witaxamt_exp', i));
                lineWhAmount = parseFloat(lineWhAmount) * parseFloat(exchangerate);
                nlapiLogExecution('DEBUG', 'Redondeo impuesto', 'init wh' + lineWhAmount);
                var amountWh = parseInt(Math.round(lineWhAmount * -1) * -1);
                amountWh = Math.round(parseFloat(amountWh) / parseFloat(exchangerate));
                nlapiLogExecution('DEBUG', title, 'init wh2' + amountWh);
                VendorBill.setLineItemValue('expense', 'custcol_4601_witaxamt_exp', i, amountWh);


                journalLine.originalAmount = parseFloat(originalAmount);
                journalLine.newAmountER = parseFloat(amount * exchangerate);
                journalLine.amountDif = Math.abs(parseFloat(originalAmount)) - Math.abs(parseFloat(amount * exchangerate));
                journalLine.account = parseInt(accountLine);
                journalLine.locationId = parseInt(VendorBill.getLineItemValue('item', 'location', i));
                journalLine.classId = parseInt(VendorBill.getLineItemValue('item', 'class', i));
                journalLine.departmentId = parseInt(VendorBill.getLineItemValue('item', 'department', i));
                if (parseFloat(journalLine.amountDif) != 0) {
                    JournalLines.push(journalLine);
                }
            }
        }
        var IdVendor = nlapiSubmitRecord(VendorBill);
        var journalId = adjJournal(id, JournalLines)
        nlapiLogExecution('DEBUG', 'adjJournal', 'journal updated/Created ' + journalId);

        nlapiLogExecution('DEBUG', 'Redondeo impuesto', 'actualizado' + IdVendor);
        return IdVendor;
    } catch (e) {
        nlapiLogExecution('ERROR', title, 'Detalles:: ' + e);
    }
}


var SETUP = {
    ACCOUNTS: {
        JOURNAL_ADJ: 949,
    },
    STATUS: {
        APPROVED: 2,
        JOURNAL_TYPE_TRM: 5
    }
}

function adjJournal(internalId, JournalLines) {
    try {
        var title = 'adjJournal'
        nlapiLogExecution('DEBUG', title, 'JournalLines: ' + JSON.stringify(JournalLines));
        //Createn Adjustment Journal
        if (JournalLines && JournalLines.length > 0 && internalId) {
            var VendorBill = nlapiLoadRecord('vendorbill', internalId);
            var subsidiary = VendorBill.getFieldValue('subsidiary');
            var currency = VendorBill.getFieldValue('currency');
            var memo = VendorBill.getFieldValue('memo');
            var trandate = VendorBill.getFieldValue('trandate');
            var entity = VendorBill.getFieldValue('entity');
            var gClass = VendorBill.getFieldValue('class');
            var gLocation = VendorBill.getFieldValue('location');
            var gDepartment = VendorBill.getFieldValue('department');

            var accountOrigenDolares = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_origen_dol');
            var accountOrigen = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_origen');
            var accountDestino = nlapiLookupField('customrecord_kis_account_setup_det', 1, 'custrecord_kis_detracciones_destino');
            nlapiLogExecution('DEBUG', title, 'accountOrigenDollars: ' + accountOrigenDolares);
            nlapiLogExecution('DEBUG', title, 'accountDestino: ' + accountDestino);
            nlapiLogExecution('DEBUG', title, 'accountOrigen: ' + accountOrigen);


            var filters = new Array();
            filters[0] = new nlobjSearchFilter('custbody_ks_pe_factura_vinculada', null, 'anyof', [internalId]);
            filters[1] = new nlobjSearchFilter('custbody_ks_pe_tipo_journal', null, 'anyof', [ksJournalAdjDet]);
            var columns = new Array();
            columns[0] = new nlobjSearchColumn('internalid');
            var journalResults = nlapiSearchRecord('journalentry', null, filters, columns);
            nlapiLogExecution('DEBUG', title, 'journalResults: ' + JSON.stringify(journalResults));
            var newJournal = null
            var mode = 'create';
            if (!journalResults) {
                nlapiLogExecution('DEBUG', 'New Adj journal', 'init create for transaction: ' + internalId);
                newJournal = nlapiCreateRecord('journalentry');
                newJournal.setFieldValue('subsidiary', subsidiary);
            } else {
                var journalId = journalResults[0].getValue(columns[0]);
                nlapiLogExecution('DEBUG', 'Update Adj journal', 'init Update for transaction: ' + internalId);
                newJournal = nlapiLoadRecord('journalentry', journalId);
                mode = 'edit'
            }

            if (newJournal != null) {
                nlapiLogExecution('DEBUG', 'New Adj journal', 'init... ');
                // New Journal Entry Body Fields
                newJournal.setFieldValue('currency', currencyDet);
                newJournal.setFieldValue('memo', memo);
                newJournal.setFieldValue('trandate', trandate);
                newJournal.setFieldValue('approvalstatus', SETUP.STATUS.APPROVED)
                newJournal.setFieldValue('custbody_ks_pe_factura_vinculada', internalId);
                newJournal.setFieldValue('custbody_ks_pe_tipo_journal', ksJournalAdjDet);

                //New Journal Entry Lines - Accourding to Journal Type (the function can be used again for other type of journal creation if necesary)
                var totalDifAm = 0;
                var currentLine = 0;
                nlapiLogExecution('DEBUG', 'New Adj journal', 'Creating Lines... ');
                for (var jl = 0; jl < JournalLines.length; jl++) {
                    //Journal Entry Line jl - Reverse Accounting Movement of the Original transaction GL
                    currentLine++;
                    var currentJline = JournalLines[jl];

                    if (mode == 'create') {
                        newJournal.selectNewLineItem('line');
                    } else {
                        newJournal.selectLineItem('line', currentLine);
                    }
                    nlapiLogExecution('DEBUG', title, 'Creating Line: ' + currentLine);
                    totalDifAm = parseFloat(totalDifAm) + parseFloat(currentJline.amountDif);
                    nlapiLogExecution('DEBUG', title, 'Creating Line: ' + JSON.stringify(currentJline));
                    newJournal.setCurrentLineItemValue('line', 'account', currentJline.account);
                    var lineType = 'debit'
                    if (parseFloat(currentJline.amountDif) > 0) {
                        lineType = 'credit'
                    }
                    nlapiLogExecution('DEBUG', title, 'lineType: ' + lineType);
                    newJournal.setCurrentLineItemValue('line', lineType, (currentJline.amountDif).toFixed(2));
                    newJournal.setCurrentLineItemValue('line', 'memo', memo);
                    if (parseInt(entity) > 0 && entity != '' && entity != null) {
                        newJournal.setCurrentLineItemValue('line', 'entity', entity);
                    }
                    if (parseInt(currentJline.classId) > 0 && currentJline.classId != '' && currentJline.classId != null) {
                        newJournal.setCurrentLineItemValue('line', 'class', currentJline.classId);
                    }
                    if (parseInt(currentJline.departmentId) > 0 && currentJline.locationId != '' && currentJline.departmentId != null) {
                        newJournal.setCurrentLineItemValue('line', 'department', currentJline.departmentId);
                    }
                    if (parseInt(currentJline.locationId) > 0 && currentJline.locationId != '' && currentJline.locationId != null) {
                        newJournal.setCurrentLineItemValue('line', 'location', currentJline.locationId);
                    }
                    newJournal.commitLineItem('line');

                }

                if (totalDifAm != 0) {
                    currentLine++;
                    var lineType = 'credit'
                    if (parseFloat(totalDifAm) > 0) {
                        lineType = 'debit'
                    }
                    nlapiLogExecution('DEBUG', title, 'lineType: ' + lineType);
                    nlapiLogExecution('DEBUG', title, 'Journal totalDifAm ' + totalDifAm);
                    if (mode == 'create') {
                        newJournal.selectNewLineItem('line');
                    } else {
                        newJournal.selectLineItem('line', currentLine);
                    }
                    newJournal.setCurrentLineItemValue('line', 'account', SETUP.ACCOUNTS.JOURNAL_ADJ);
                    newJournal.setCurrentLineItemValue('line', lineType, (totalDifAm).toFixed(2));
                    newJournal.setCurrentLineItemValue('line', 'memo', memo);
                    if (parseInt(entity) > 0 && entity != '' && entity != null) {
                        newJournal.setCurrentLineItemValue('line', 'entity', entity);
                    }
                    if (parseInt(gClass) > 0 && gClass != '' && gClass != null) {
                        newJournal.setCurrentLineItemValue('line', 'class', gClass);
                    }
                    if (parseInt(gDepartment) > 0 && gDepartment != '' && gDepartment != null) {
                        newJournal.setCurrentLineItemValue('line', 'department', gDepartment);
                    }
                    if (parseInt(gLocation) > 0 && gLocation != '' && gClass != null) {
                        newJournal.setCurrentLineItemValue('line', 'location', gLocation);
                    }
                    newJournal.commitLineItem('line');
                    nlapiLogExecution('DEBUG', title, 'Creating Line: ' + currentLine);
                }

                var newJounalId = nlapiSubmitRecord(newJournal, false, true);
                nlapiLogExecution('DEBUG', title, 'Journal Created/Updated: ' + newJounalId);
                return newJounalId;
            } else {
                nlapiLogExecution('DEBUG', title, 'Error creating/Updating Record');
                return null
            }
        } else {
            nlapiLogExecution('DEBUG', title, 'Adjustment Journal Not necessary');
            return null
        }
    } catch (error) {
        nlapiLogExecution('ERROR', title, error);
    }
}


function deleteJournal(id) {
    var filters = new Array();
    filters[0] = new nlobjSearchFilter('custbody_ks_pe_factura_vinculada', null, 'is', id);
    var columns = new Array();
    columns[0] = new nlobjSearchColumn('internalid');

    var journalResults = nlapiSearchRecord('journalentry', null, filters, columns);

    if (journalResults) {
        for (j = 0; j <= journalResults.length; j++) {
            var journalId = journalResults[j].getValue(columns[0]);
            nlapiLogExecution('DEBUG', 'Jpurnal a actualizar', journalId);
            nlapiDeleteRecord('journalentry', journalId);

        }
    }
}