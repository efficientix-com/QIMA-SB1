/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       12 Dec 2017     John Hernandez
 * 
 * 
 *	Script de evento de usuario para controlar y ejecutar la creaci�n de journals de detracciones 
 */

function recDetrabeforeSubmit(type) {
    var method = 'recDetrabeforeSubmit'
    try {
        var newRecord = nlapiGetNewRecord();
        var recType = nlapiGetRecordType().toLowerCase();
        var recId = nlapiGetRecordId();

        if (recType == 'vendorbill') {
            /**
             * Si se elimina la factura se elimina el journal
             */
            if (type == 'delete') {
                var recId = nlapiGetRecordId();
                deleteJournal(recId);
            }
            var whBase = nlapiGetFieldValue('custpage_4601_witaxbaseamount');
            var whTaxAmount = nlapiGetFieldValue('custpage_4601_witaxamount');
            nlapiSetFieldValue("custbody_kspe_wh_base", whBase)
            nlapiSetFieldValue("custbody_kspe_wh_amount", whTaxAmount)
        }



    } catch (e) {
        nlapiLogExecution('ERROR', method, e)
    }
}

function recDetraAfterSubmit(type) {
    var method = 'recDetraAfterSubmit'
    try {
        //Valida el tipo de operacion realizada sobre el registro
        if (type != 'delete' && type != 'xedit') {
            var newRecord = nlapiGetNewRecord();
            var recType = nlapiGetRecordType().toLowerCase();
            var recId = nlapiGetRecordId();
            var recType = nlapiGetRecordType().toLowerCase();
            //Valida que el registro sea un vendor bill
            if (recType == 'vendorbill') {
                var context = nlapiGetContext();
                var moneda = context.getSetting('SCRIPT', 'custscript_ks_pe_monedadetraccion');
                nlapiLogExecution('DEBUG', method, 'moneda:' + moneda)

                if (type == 'create' || type == 'copy') {
                    var ajuste = RoundTax(recId);

                    var journal = createJournal(recId, moneda);
                    //nlapiLogExecution('DEBUG', 'vendorBillJournal', 'journal created 2'+journal);
                    nlapiLogExecution('DEBUG', method, 'CREACIÓN JOURNAL' + journal)
                }
                if (type == 'edit') {
                    var ajuste = RoundTax(recId);
                    //Llamado a la funci�n para editar journal de detracciones
                    var journal = editJournal(recId, moneda);
                    //nlapiSubmitField(recType, recId, 'custbody_ks_pe_factura_vinculada', journal);
                    nlapiLogExecution('DEBUG', method, 'EDICIÓN JOURNAL' + journal)
                }
            }
        }
    } catch (e) {
        nlapiLogExecution('ERROR', method, e);

    }
}